[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / [react-autonomy](../modules/react_autonomy.md) / AuthErrorCodes

# Enumeration: AuthErrorCodes

[react-autonomy](../modules/react_autonomy.md).AuthErrorCodes

## Table of contents

### Enumeration Members

- [InternalError](react_autonomy.AuthErrorCodes.md#internalerror)
- [MissingApiKey](react_autonomy.AuthErrorCodes.md#missingapikey)
- [Unauthorized](react_autonomy.AuthErrorCodes.md#unauthorized)

## Enumeration Members

### InternalError

• **InternalError** = ``"INTERNAL_ERROR"``

#### Defined in

[packages/react-autonomy/src/types.ts:25](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/types.ts#L25)

___

### MissingApiKey

• **MissingApiKey** = ``"MISSING_API_KEY"``

#### Defined in

[packages/react-autonomy/src/types.ts:26](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/types.ts#L26)

___

### Unauthorized

• **Unauthorized** = ``"UNAUTHORIZED"``

#### Defined in

[packages/react-autonomy/src/types.ts:24](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/types.ts#L24)
