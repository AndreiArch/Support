[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / [react-autonomy](../modules/react_autonomy.md) / SkipSubscription

# Interface: SkipSubscription

[react-autonomy](../modules/react_autonomy.md).SkipSubscription

## Table of contents

### Properties

- [products](react_autonomy.SkipSubscription.md#products)

## Properties

### products

• `Optional` **products**: [`Product`](react_autonomy.Product.md)[]

#### Defined in

[packages/react-autonomy/src/redux/actions/subscriptions/skip-subscription.ts:36](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/subscriptions/skip-subscription.ts#L36)
