[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / [react-autonomy](../modules/react_autonomy.md) / UseProduct

# Interface: UseProduct

[react-autonomy](../modules/react_autonomy.md).UseProduct

`UseProduct` contains the data and methods returned by the [useProduct](../modules/react_autonomy.md#useproduct)
hook.

## Table of contents

### Properties

- [createStockRequest](react_autonomy.UseProduct.md#createstockrequest)

## Properties

### createStockRequest

• **createStockRequest**: (`options`: [`CreateStockRequest`](react_autonomy.CreateStockRequest.md)) => `Promise`<`void`\>

#### Type declaration

▸ (`options`): `Promise`<`void`\>

The `createStockRequest` adds the customer to a product variant wait list
in the OMS. When the variant is marked back in stock, customers on the wait
list will automatically receive an email notification.

**`Example`**

```javascript
import { useProduct } from '@chordcommerce/react-autonomy'

const NotifyWhenBackInStockButton = ({ email, sku }) => {
  const { createStockRequest } = useProduct()

  const onClick = () => createStockRequest({ email, sku })

  return <button onClick={onClick}>Notify</button>
}
```

##### Parameters

| Name | Type |
| :------ | :------ |
| `options` | [`CreateStockRequest`](react_autonomy.CreateStockRequest.md) |

##### Returns

`Promise`<`void`\>

A Promise that resolves when the stock request has been created.

#### Defined in

[packages/react-autonomy/src/hooks/use-product.ts:74](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-product.ts#L74)
