[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / [react-autonomy](../modules/react_autonomy.md) / Adjustment

# Interface: Adjustment

[react-autonomy](../modules/react_autonomy.md).Adjustment

## Table of contents

### Properties

- [adjustableId](react_autonomy.Adjustment.md#adjustableid)
- [adjustableType](react_autonomy.Adjustment.md#adjustabletype)
- [amount](react_autonomy.Adjustment.md#amount)
- [createdAt](react_autonomy.Adjustment.md#createdat)
- [displayAmount](react_autonomy.Adjustment.md#displayamount)
- [eligible](react_autonomy.Adjustment.md#eligible)
- [finalized](react_autonomy.Adjustment.md#finalized)
- [id](react_autonomy.Adjustment.md#id)
- [label](react_autonomy.Adjustment.md#label)
- [promotionCode](react_autonomy.Adjustment.md#promotioncode)
- [promotionCodeId](react_autonomy.Adjustment.md#promotioncodeid)
- [sourceId](react_autonomy.Adjustment.md#sourceid)
- [sourceType](react_autonomy.Adjustment.md#sourcetype)
- [updatedAt](react_autonomy.Adjustment.md#updatedat)

## Properties

### adjustableId

• **adjustableId**: `number`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:23

___

### adjustableType

• **adjustableType**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:24

___

### amount

• **amount**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:25

___

### createdAt

• **createdAt**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:26

___

### displayAmount

• **displayAmount**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:27

___

### eligible

• **eligible**: `boolean`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:28

___

### finalized

• **finalized**: `boolean`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:29

___

### id

• **id**: `number`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:30

___

### label

• **label**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:31

___

### promotionCode

• **promotionCode**: `PromotionCode`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:36

___

### promotionCodeId

• **promotionCodeId**: `number`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:32

___

### sourceId

• **sourceId**: `number`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:33

___

### sourceType

• **sourceType**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:34

___

### updatedAt

• **updatedAt**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:35
