[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / [react-autonomy](../modules/react_autonomy.md) / TrackEmailCaptured

# Interface: TrackEmailCaptured

[react-autonomy](../modules/react_autonomy.md).TrackEmailCaptured

## Table of contents

### Properties

- [emailCapture](react_autonomy.TrackEmailCaptured.md#emailcapture)

## Properties

### emailCapture

• **emailCapture**: `Object`

#### Type declaration

| Name | Type | Description |
| :------ | :------ | :------ |
| `component?` | `string` | HTML component within the UX, such as header, footer, modal. |
| `email` | `string` | The email address that was captured. |
| `page?` | `string` | Page of the website (or `Sitewide` for whole website). |
| `website?` | `string` | Hostname of the website. |

#### Defined in

[packages/react-autonomy/src/redux/actions/analytics/track-email-captured.ts:4](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/analytics/track-email-captured.ts#L4)
