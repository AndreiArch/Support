[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / [react-autonomy](../modules/react_autonomy.md) / OrderBig

# Interface: OrderBig

[react-autonomy](../modules/react_autonomy.md).OrderBig

## Table of contents

### Properties

- [additionalTaxTotal](react_autonomy.OrderBig.md#additionaltaxtotal)
- [adjustmentTotal](react_autonomy.OrderBig.md#adjustmenttotal)
- [adjustments](react_autonomy.OrderBig.md#adjustments)
- [billAddress](react_autonomy.OrderBig.md#billaddress)
- [cancelerId](react_autonomy.OrderBig.md#cancelerid)
- [channel](react_autonomy.OrderBig.md#channel)
- [checkoutSteps](react_autonomy.OrderBig.md#checkoutsteps)
- [completedAt](react_autonomy.OrderBig.md#completedat)
- [coveredByStoreCredit](react_autonomy.OrderBig.md#coveredbystorecredit)
- [createdAt](react_autonomy.OrderBig.md#createdat)
- [creditCards](react_autonomy.OrderBig.md#creditcards)
- [currency](react_autonomy.OrderBig.md#currency)
- [displayAdditionalTaxTotal](react_autonomy.OrderBig.md#displayadditionaltaxtotal)
- [displayIncludedTaxTotal](react_autonomy.OrderBig.md#displayincludedtaxtotal)
- [displayItemTotal](react_autonomy.OrderBig.md#displayitemtotal)
- [displayOrderTotalAfterStoreCredit](react_autonomy.OrderBig.md#displayordertotalafterstorecredit)
- [displayShipTotal](react_autonomy.OrderBig.md#displayshiptotal)
- [displayStoreCreditRemainingAfterCapture](react_autonomy.OrderBig.md#displaystorecreditremainingaftercapture)
- [displayTaxTotal](react_autonomy.OrderBig.md#displaytaxtotal)
- [displayTotal](react_autonomy.OrderBig.md#displaytotal)
- [displayTotalApplicableStoreCredit](react_autonomy.OrderBig.md#displaytotalapplicablestorecredit)
- [displayTotalAvailableStoreCredit](react_autonomy.OrderBig.md#displaytotalavailablestorecredit)
- [email](react_autonomy.OrderBig.md#email)
- [id](react_autonomy.OrderBig.md#id)
- [includedTaxTotal](react_autonomy.OrderBig.md#includedtaxtotal)
- [itemTotal](react_autonomy.OrderBig.md#itemtotal)
- [lineItems](react_autonomy.OrderBig.md#lineitems)
- [metadata](react_autonomy.OrderBig.md#metadata)
- [number](react_autonomy.OrderBig.md#number)
- [orderTotalAfterStoreCredit](react_autonomy.OrderBig.md#ordertotalafterstorecredit)
- [paymentMethods](react_autonomy.OrderBig.md#paymentmethods)
- [paymentState](react_autonomy.OrderBig.md#paymentstate)
- [paymentTotal](react_autonomy.OrderBig.md#paymenttotal)
- [payments](react_autonomy.OrderBig.md#payments)
- [permissions](react_autonomy.OrderBig.md#permissions)
- [shipAddress](react_autonomy.OrderBig.md#shipaddress)
- [shipTotal](react_autonomy.OrderBig.md#shiptotal)
- [shipmentState](react_autonomy.OrderBig.md#shipmentstate)
- [shipments](react_autonomy.OrderBig.md#shipments)
- [specialInstructions](react_autonomy.OrderBig.md#specialinstructions)
- [state](react_autonomy.OrderBig.md#state)
- [store](react_autonomy.OrderBig.md#store)
- [taxTotal](react_autonomy.OrderBig.md#taxtotal)
- [token](react_autonomy.OrderBig.md#token)
- [total](react_autonomy.OrderBig.md#total)
- [totalApplicableStoreCredit](react_autonomy.OrderBig.md#totalapplicablestorecredit)
- [totalQuantity](react_autonomy.OrderBig.md#totalquantity)
- [updatedAt](react_autonomy.OrderBig.md#updatedat)
- [userId](react_autonomy.OrderBig.md#userid)

## Properties

### additionalTaxTotal

• **additionalTaxTotal**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:43

___

### adjustmentTotal

• **adjustmentTotal**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:44

___

### adjustments

• **adjustments**: [`Adjustment`](react_autonomy.Adjustment.md)[]

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:45

___

### billAddress

• **billAddress**: `Address`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:46

___

### cancelerId

• **cancelerId**: `number`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:47

___

### channel

• **channel**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:48

___

### checkoutSteps

• **checkoutSteps**: `string`[]

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:49

___

### completedAt

• **completedAt**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:50

___

### coveredByStoreCredit

• **coveredByStoreCredit**: `boolean`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:51

___

### createdAt

• **createdAt**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:52

___

### creditCards

• **creditCards**: `CreditCard`[]

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:53

___

### currency

• **currency**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:54

___

### displayAdditionalTaxTotal

• **displayAdditionalTaxTotal**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:55

___

### displayIncludedTaxTotal

• **displayIncludedTaxTotal**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:56

___

### displayItemTotal

• **displayItemTotal**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:57

___

### displayOrderTotalAfterStoreCredit

• **displayOrderTotalAfterStoreCredit**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:58

___

### displayShipTotal

• **displayShipTotal**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:59

___

### displayStoreCreditRemainingAfterCapture

• **displayStoreCreditRemainingAfterCapture**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:60

___

### displayTaxTotal

• **displayTaxTotal**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:61

___

### displayTotal

• **displayTotal**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:62

___

### displayTotalApplicableStoreCredit

• **displayTotalApplicableStoreCredit**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:63

___

### displayTotalAvailableStoreCredit

• **displayTotalAvailableStoreCredit**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:64

___

### email

• **email**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:65

___

### id

• **id**: `number`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:66

___

### includedTaxTotal

• **includedTaxTotal**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:67

___

### itemTotal

• **itemTotal**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:68

___

### lineItems

• **lineItems**: `LineItem`[]

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:69

___

### metadata

• **metadata**: [`Metadata`](../modules/react_autonomy.md#metadata)

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:95

___

### number

• **number**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:70

___

### orderTotalAfterStoreCredit

• **orderTotalAfterStoreCredit**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:71

___

### paymentMethods

• **paymentMethods**: `PaymentMethod`[]

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:72

___

### paymentState

• **paymentState**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:73

___

### paymentTotal

• **paymentTotal**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:74

___

### payments

• **payments**: `Payment`[]

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:75

___

### permissions

• **permissions**: `OrderPermissions`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:76

___

### shipAddress

• **shipAddress**: `Address`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:77

___

### shipTotal

• **shipTotal**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:78

___

### shipmentState

• **shipmentState**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:79

___

### shipments

• **shipments**: `Shipment`[]

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:80

___

### specialInstructions

• **specialInstructions**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:81

___

### state

• **state**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:82

___

### store

• **store**: `Object`

#### Type declaration

| Name | Type |
| :------ | :------ |
| `code` | `string` |
| `id` | `number` |
| `name` | `string` |

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:83

___

### taxTotal

• **taxTotal**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:88

___

### token

• **token**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:89

___

### total

• **total**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:90

___

### totalApplicableStoreCredit

• **totalApplicableStoreCredit**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:91

___

### totalQuantity

• **totalQuantity**: `number`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:92

___

### updatedAt

• **updatedAt**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:93

___

### userId

• **userId**: `number`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:94
