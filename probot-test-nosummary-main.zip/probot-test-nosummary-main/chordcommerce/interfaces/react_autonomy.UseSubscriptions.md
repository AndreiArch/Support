[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / [react-autonomy](../modules/react_autonomy.md) / UseSubscriptions

# Interface: UseSubscriptions

[react-autonomy](../modules/react_autonomy.md).UseSubscriptions

`UseSubscriptions` contains the data and methods returned by the
[useSubscriptions](../modules/react_autonomy.md#usesubscriptions) hook.

## Table of contents

### Properties

- [error](react_autonomy.UseSubscriptions.md#error)
- [isFetching](react_autonomy.UseSubscriptions.md#isfetching)
- [isLoaded](react_autonomy.UseSubscriptions.md#isloaded)
- [loadSubscriptions](react_autonomy.UseSubscriptions.md#loadsubscriptions)
- [subscriptions](react_autonomy.UseSubscriptions.md#subscriptions)

## Properties

### error

• **error**: `Error`

#### Defined in

[packages/react-autonomy/src/hooks/use-subscriptions.ts:100](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-subscriptions.ts#L100)

___

### isFetching

• **isFetching**: `boolean`

#### Defined in

[packages/react-autonomy/src/hooks/use-subscriptions.ts:99](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-subscriptions.ts#L99)

___

### isLoaded

• **isLoaded**: `boolean`

#### Defined in

[packages/react-autonomy/src/hooks/use-subscriptions.ts:98](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-subscriptions.ts#L98)

___

### loadSubscriptions

• **loadSubscriptions**: () => `Promise`<[`Subscription`](react_autonomy.Subscription.md)[]\>

#### Type declaration

▸ (): `Promise`<[`Subscription`](react_autonomy.Subscription.md)[]\>

Loads all subscriptions that the customer might have for the store. This
function should only need to be called in exceptional circumstances, as
[useSubscriptions](../modules/react_autonomy.md#usesubscriptions) automatically calls this.

##### Returns

`Promise`<[`Subscription`](react_autonomy.Subscription.md)[]\>

#### Defined in

[packages/react-autonomy/src/hooks/use-subscriptions.ts:106](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-subscriptions.ts#L106)

___

### subscriptions

• **subscriptions**: [`Subscription`](react_autonomy.Subscription.md)[]

#### Defined in

[packages/react-autonomy/src/hooks/use-subscriptions.ts:97](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-subscriptions.ts#L97)
