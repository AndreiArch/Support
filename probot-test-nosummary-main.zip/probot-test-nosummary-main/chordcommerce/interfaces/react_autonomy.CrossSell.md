[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / [react-autonomy](../modules/react_autonomy.md) / CrossSell

# Interface: CrossSell

[react-autonomy](../modules/react_autonomy.md).CrossSell

## Table of contents

### Properties

- [cart](react_autonomy.CrossSell.md#cart)
- [lineItemsAttributes](react_autonomy.CrossSell.md#lineitemsattributes)

## Properties

### cart

• **cart**: `OrderIdentifier`

#### Defined in

[packages/react-autonomy/src/redux/actions/cart/add-cross-sell.ts:31](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/cart/add-cross-sell.ts#L31)

___

### lineItemsAttributes

• **lineItemsAttributes**: `LineItemAttributesInput`[]

An array of line item objects that can be both subscription and standard
line items.

#### Defined in

[packages/react-autonomy/src/redux/actions/cart/add-cross-sell.ts:36](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/cart/add-cross-sell.ts#L36)
