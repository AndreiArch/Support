[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / [react-autonomy](../modules/react_autonomy.md) / ResumeSubscription

# Interface: ResumeSubscription

[react-autonomy](../modules/react_autonomy.md).ResumeSubscription

## Table of contents

### Properties

- [actionableDate](react_autonomy.ResumeSubscription.md#actionabledate)
- [products](react_autonomy.ResumeSubscription.md#products)

## Properties

### actionableDate

• **actionableDate**: `string`

#### Defined in

[packages/react-autonomy/src/redux/actions/subscriptions/resume-subscription.ts:36](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/subscriptions/resume-subscription.ts#L36)

___

### products

• `Optional` **products**: [`Product`](react_autonomy.Product.md)[]

#### Defined in

[packages/react-autonomy/src/redux/actions/subscriptions/resume-subscription.ts:37](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/subscriptions/resume-subscription.ts#L37)
