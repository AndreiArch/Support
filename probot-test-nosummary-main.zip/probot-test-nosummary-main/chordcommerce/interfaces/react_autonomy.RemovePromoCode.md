[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / [react-autonomy](../modules/react_autonomy.md) / RemovePromoCode

# Interface: RemovePromoCode

[react-autonomy](../modules/react_autonomy.md).RemovePromoCode

## Table of contents

### Properties

- [promoCode](react_autonomy.RemovePromoCode.md#promocode)

## Properties

### promoCode

• **promoCode**: `string`

#### Defined in

[packages/react-autonomy/src/redux/actions/cart/remove-promo-code.ts:41](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/cart/remove-promo-code.ts#L41)
