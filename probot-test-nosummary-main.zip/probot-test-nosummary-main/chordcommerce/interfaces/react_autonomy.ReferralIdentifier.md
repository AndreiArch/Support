[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / [react-autonomy](../modules/react_autonomy.md) / ReferralIdentifier

# Interface: ReferralIdentifier

[react-autonomy](../modules/react_autonomy.md).ReferralIdentifier

## Table of contents

### Properties

- [purl](react_autonomy.ReferralIdentifier.md#purl)
- [uid](react_autonomy.ReferralIdentifier.md#uid)

## Properties

### purl

• **purl**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:408

___

### uid

• **uid**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:409
