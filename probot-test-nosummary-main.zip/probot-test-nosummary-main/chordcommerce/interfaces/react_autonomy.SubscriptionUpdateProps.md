[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / [react-autonomy](../modules/react_autonomy.md) / SubscriptionUpdateProps

# Interface: SubscriptionUpdateProps

[react-autonomy](../modules/react_autonomy.md).SubscriptionUpdateProps

## Table of contents

### Properties

- [actionableDate](react_autonomy.SubscriptionUpdateProps.md#actionabledate)
- [bill\_address\_attributes](react_autonomy.SubscriptionUpdateProps.md#bill_address_attributes)
- [endDate](react_autonomy.SubscriptionUpdateProps.md#enddate)
- [intervalLength](react_autonomy.SubscriptionUpdateProps.md#intervallength)
- [intervalUnits](react_autonomy.SubscriptionUpdateProps.md#intervalunits)
- [payment\_source\_attributes](react_autonomy.SubscriptionUpdateProps.md#payment_source_attributes)
- [ship\_address\_attributes](react_autonomy.SubscriptionUpdateProps.md#ship_address_attributes)

## Properties

### actionableDate

• `Optional` **actionableDate**: `string`

A date string representing when the subscription should resume. The minimum
date is the next day. If `actionableDate` is omitted, the subscription will
be resumed the next day.

#### Defined in

[packages/react-autonomy/src/redux/actions/subscriptions/update-subscription.ts:88](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/subscriptions/update-subscription.ts#L88)

___

### bill\_address\_attributes

• `Optional` **bill\_address\_attributes**: [`SubscriptionAddress`](../modules/react_autonomy.md#subscriptionaddress)

An object representing the billing address. All fields need to be sent even
if only a single field is updated.

#### Defined in

[packages/react-autonomy/src/redux/actions/subscriptions/update-subscription.ts:57](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/subscriptions/update-subscription.ts#L57)

___

### endDate

• `Optional` **endDate**: `string`

A string representing the end date of the subscription. If `null`, the
subscription will renew indefinitely.

#### Defined in

[packages/react-autonomy/src/redux/actions/subscriptions/update-subscription.ts:82](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/subscriptions/update-subscription.ts#L82)

___

### intervalLength

• `Optional` **intervalLength**: `number`

The number of units. _Example:_ if the subscription should be delivered
every three months, this would be `3`.

#### Defined in

[packages/react-autonomy/src/redux/actions/subscriptions/update-subscription.ts:72](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/subscriptions/update-subscription.ts#L72)

___

### intervalUnits

• `Optional` **intervalUnits**: [`IntervalUnit`](../modules/react_autonomy.md#intervalunit)

The interval unit. _Example:_ if the subscription should be delivered every
three months, this would be `month`.

#### Defined in

[packages/react-autonomy/src/redux/actions/subscriptions/update-subscription.ts:77](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/subscriptions/update-subscription.ts#L77)

___

### payment\_source\_attributes

• `Optional` **payment\_source\_attributes**: [`SubscriptionPaymentSource`](../modules/react_autonomy.md#subscriptionpaymentsource)

An object representing the payment source. All fields need to be sent
even if only a single field is updated.

#### Defined in

[packages/react-autonomy/src/redux/actions/subscriptions/update-subscription.ts:67](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/subscriptions/update-subscription.ts#L67)

___

### ship\_address\_attributes

• `Optional` **ship\_address\_attributes**: [`SubscriptionAddress`](../modules/react_autonomy.md#subscriptionaddress)

An object representing the shipping address. All fields need to be sent
even if only a single field is updated.

#### Defined in

[packages/react-autonomy/src/redux/actions/subscriptions/update-subscription.ts:62](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/subscriptions/update-subscription.ts#L62)
