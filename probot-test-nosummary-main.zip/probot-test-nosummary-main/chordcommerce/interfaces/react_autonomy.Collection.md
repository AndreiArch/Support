[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / [react-autonomy](../modules/react_autonomy.md) / Collection

# Interface: Collection

[react-autonomy](../modules/react_autonomy.md).Collection

## Table of contents

### Properties

- [brand](react_autonomy.Collection.md#brand)
- [collectionId](react_autonomy.Collection.md#collectionid)
- [title](react_autonomy.Collection.md#title)
- [url](react_autonomy.Collection.md#url)

## Properties

### brand

• `Optional` **brand**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/analytics/types/objects.d.ts:3

___

### collectionId

• **collectionId**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/analytics/types/objects.d.ts:4

___

### title

• **title**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/analytics/types/objects.d.ts:5

___

### url

• **url**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/analytics/types/objects.d.ts:6
