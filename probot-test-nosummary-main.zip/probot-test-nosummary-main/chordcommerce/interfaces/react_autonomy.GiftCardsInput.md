[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / [react-autonomy](../modules/react_autonomy.md) / GiftCardsInput

# Interface: GiftCardsInput

[react-autonomy](../modules/react_autonomy.md).GiftCardsInput

## Table of contents

### Properties

- [giftCards](react_autonomy.GiftCardsInput.md#giftcards)

## Properties

### giftCards

• **giftCards**: `Object`

#### Type declaration

| Name | Type |
| :------ | :------ |
| `giftCardsDetails` | [`GiftCardsDetailsInput`](react_autonomy.GiftCardsDetailsInput.md)[] |

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/inputs.d.ts:272
