[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / [react-autonomy](../modules/react_autonomy.md) / UseAnalytics

# Interface: UseAnalytics

[react-autonomy](../modules/react_autonomy.md).UseAnalytics

`UseAnalytics` contains the tracking functions returned by [useAnalytics](../modules/react_autonomy.md#useanalytics).

## Table of contents

### Properties

- [chordAnalytics](react_autonomy.UseAnalytics.md#chordanalytics)
- [trackCartViewed](react_autonomy.UseAnalytics.md#trackcartviewed)
- [trackCollectionClicked](react_autonomy.UseAnalytics.md#trackcollectionclicked)
- [trackEmailCaptured](react_autonomy.UseAnalytics.md#trackemailcaptured)
- [trackProductClicked](react_autonomy.UseAnalytics.md#trackproductclicked)
- [trackProductViewed](react_autonomy.UseAnalytics.md#trackproductviewed)
- [trackVariantClicked](react_autonomy.UseAnalytics.md#trackvariantclicked)

## Properties

### chordAnalytics

• **chordAnalytics**: `AnalyticsClient`

This provides low level access to Chord's analytics client.

#### Defined in

[packages/react-autonomy/src/hooks/use-analytics.ts:87](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-analytics.ts#L87)

___

### trackCartViewed

• **trackCartViewed**: (`options?`: [`TrackCartViewed`](../modules/react_autonomy.md#trackcartviewed)) => { `payload`: [`TrackCartViewed`](../modules/react_autonomy.md#trackcartviewed) = options; `type`: `string` = TRACK\_CART\_VIEWED }

#### Type declaration

▸ (`options?`): `Object`

The `trackCartViewed` function sends a `Cart Viewed` event to
Segment. You should call this function when the cart page is
viewed.

**`Example`**

```javascript
import { useAnalytics, useCart } from '@chordcommerce/react-autonomy'
import { useEffect } from 'react'

const CartPage = () => {
  const { cart, loadCart, isLoaded, isFetching } = useCart()
  const { trackCartViewed } = useAnalytics()

  useEffect(() => {
    if (!isLoaded && !isFetching) {
      loadCart().catch(error => console.error('could not loadCart', error))
    }
  }, [loadCart, isLoaded, isFetching])

  useEffect(() => {
    if (isLoaded) {
      trackCartViewed({
        products: cart?.lineItems ?? []
      })
    }
    // Only track isLoaded so that this only fires once.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isLoaded])

  // return cart page
}
```

##### Parameters

| Name | Type |
| :------ | :------ |
| `options?` | [`TrackCartViewed`](../modules/react_autonomy.md#trackcartviewed) |

##### Returns

`Object`

| Name | Type |
| :------ | :------ |
| `payload` | [`TrackCartViewed`](../modules/react_autonomy.md#trackcartviewed) |
| `type` | `string` |

#### Defined in

[packages/react-autonomy/src/hooks/use-analytics.ts:123](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-analytics.ts#L123)

___

### trackCollectionClicked

• **trackCollectionClicked**: (`options`: [`TrackCollectionClicked`](../modules/react_autonomy.md#trackcollectionclicked)) => { `payload`: [`TrackCollectionClicked`](../modules/react_autonomy.md#trackcollectionclicked) = options; `type`: `string` = TRACK\_COLLECTION\_CLICKED }

#### Type declaration

▸ (`options`): `Object`

The `trackCollectionClicked` function fires a `Collection Clicked` event to
Segment. You should call this function when the user clicks on a link to
a collection.

**`Example`**

```javascript
import { useAnalytics } from '@chordcommerce/react-autonomy'

const CollectionLink = ({ collection, children }) => {
  const { trackCollectionClicked } = useAnalytics()
  const url = `/shop/?collection=${slug}`

  return (
    <a href={url} onClick={() => trackCollectionClicked({ collection })}>
      {children}
    </a>
  )
}
```

##### Parameters

| Name | Type |
| :------ | :------ |
| `options` | [`TrackCollectionClicked`](../modules/react_autonomy.md#trackcollectionclicked) |

##### Returns

`Object`

| Name | Type |
| :------ | :------ |
| `payload` | [`TrackCollectionClicked`](../modules/react_autonomy.md#trackcollectionclicked) |
| `type` | `string` |

#### Defined in

[packages/react-autonomy/src/hooks/use-analytics.ts:146](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-analytics.ts#L146)

___

### trackEmailCaptured

• **trackEmailCaptured**: (`options`: [`TrackEmailCaptured`](react_autonomy.TrackEmailCaptured.md)) => { `payload`: [`TrackEmailCaptured`](react_autonomy.TrackEmailCaptured.md) = options; `type`: `string` = TRACK\_EMAIL\_CAPTURED }

#### Type declaration

▸ (`options`): `Object`

The `trackEmailCaptured` function sends a `Email Captured` event to Segment.
You should call this whenever the user enters an email. Examples of this can
include newsletter signups, coupon pop-ups and/or logins. This function will
also [identify the user](https://segment.com/docs/connections/spec/identify/)
to Segment so that all subsequent tracking calls will be associated with this
email.

**`Example`**

```javascript
import { useAnalytics } from '~/hook/actions'

const NewsletterForm = () => {
  const { trackEmailCaptured } = useAnalytics()
  const handleSubmit = useCallback((event) => {
    event.preventDefault()

    const payload = {
      email: event.currentTarget.elements['email'].value,
      component: 'footer',
      page: 'Sitewide',
      website: window.location.host,
    }

    trackEmailCaptured(payload)
  }, [trackEmailCaptured])

  return (
    <form onSubmit={handleSubmit}>
      <p>Sign up for our newsletter!</p>
      <input type="email" name="email" placeholder="Your Email" required />
      <button type="submit">Sign Up</button>
    </form>
  )
}
```

##### Parameters

| Name | Type |
| :------ | :------ |
| `options` | [`TrackEmailCaptured`](react_autonomy.TrackEmailCaptured.md) |

##### Returns

`Object`

| Name | Type |
| :------ | :------ |
| `payload` | [`TrackEmailCaptured`](react_autonomy.TrackEmailCaptured.md) |
| `type` | `string` |

#### Defined in

[packages/react-autonomy/src/hooks/use-analytics.ts:185](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-analytics.ts#L185)

___

### trackProductClicked

• **trackProductClicked**: (`options`: [`TrackProductClicked`](react_autonomy.TrackProductClicked.md)) => { `payload`: [`TrackProductClicked`](react_autonomy.TrackProductClicked.md) = options; `type`: `string` = TRACK\_PRODUCT\_CLICKED }

#### Type declaration

▸ (`options`): `Object`

The `trackProductClicked` function sends a `Product Clicked` event to
Segment. You should call this function when the user clicks on a link to
a product.

**`Example`**

```javascript
import { useAnalytics } from '@chordcommerce/react-autonomy'

const ProductLink = ({ children, product }) => {
  const { trackProductClicked } = useAnalytics()
  const url = `/products/${slug}/`

  return (
    <a href={url} onClick={() => trackProductClicked({ product })}>
      {children}
    </a>
  )
}
```

##### Parameters

| Name | Type |
| :------ | :------ |
| `options` | [`TrackProductClicked`](react_autonomy.TrackProductClicked.md) |

##### Returns

`Object`

| Name | Type |
| :------ | :------ |
| `payload` | [`TrackProductClicked`](react_autonomy.TrackProductClicked.md) |
| `type` | `string` |

#### Defined in

[packages/react-autonomy/src/hooks/use-analytics.ts:229](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-analytics.ts#L229)

___

### trackProductViewed

• **trackProductViewed**: (`options`: [`TrackProductViewed`](../modules/react_autonomy.md#trackproductviewed)) => { `payload`: [`TrackProductViewed`](../modules/react_autonomy.md#trackproductviewed) = options; `type`: `string` = TRACK\_PRODUCT\_VIEWED }

#### Type declaration

▸ (`options`): `Object`

The `trackProductViewed` function fires a `Product Viewed` event to Segment.
You should call this function when a product page is opened.

**`Example`**

```javascript
import { useAnalytics } from '@chordcommerce/gatsby-theme-autonomy'

export default (product) => {
  const { trackProductViewed } = useAnalytics()

  useEffect(() => {
    trackProductViewed({ product })
  }, [product])

  // return product page
}
```

##### Parameters

| Name | Type |
| :------ | :------ |
| `options` | [`TrackProductViewed`](../modules/react_autonomy.md#trackproductviewed) |

##### Returns

`Object`

| Name | Type |
| :------ | :------ |
| `payload` | [`TrackProductViewed`](../modules/react_autonomy.md#trackproductviewed) |
| `type` | `string` |

#### Defined in

[packages/react-autonomy/src/hooks/use-analytics.ts:206](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-analytics.ts#L206)

___

### trackVariantClicked

• **trackVariantClicked**: (`options`: [`TrackVariantClicked`](react_autonomy.TrackVariantClicked.md)) => { `payload`: [`TrackVariantClicked`](react_autonomy.TrackVariantClicked.md) = options; `type`: `string` = TRACK\_VARIANT\_CLICKED }

#### Type declaration

▸ (`options`): `Object`

The `trackVariantClicked` function sends a `Variant Clicked` event to
Segment. You should call this function when the user clicks on a link to

This function takes a product and not a variant.

**`Example`**

```javascript
import { useAnalytics } from '@chordcommerce/react-autonomy'

const ProductLink = ({ children, product }) => {
  const { trackVariantClicked } = useAnalytics()
  const url = `/products/${slug}/`

  return (
    <a href={url} onClick={() => trackVariantClicked({ product })}>
      {children}
    </a>
  )
}
```

##### Parameters

| Name | Type |
| :------ | :------ |
| `options` | [`TrackVariantClicked`](react_autonomy.TrackVariantClicked.md) |

##### Returns

`Object`

| Name | Type |
| :------ | :------ |
| `payload` | [`TrackVariantClicked`](react_autonomy.TrackVariantClicked.md) |
| `type` | `string` |

#### Defined in

[packages/react-autonomy/src/hooks/use-analytics.ts:253](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-analytics.ts#L253)
