[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / [react-autonomy](../modules/react_autonomy.md) / ModifyLineItem

# Interface: ModifyLineItem

[react-autonomy](../modules/react_autonomy.md).ModifyLineItem

## Table of contents

### Properties

- [attributes](react_autonomy.ModifyLineItem.md#attributes)
- [lineItemId](react_autonomy.ModifyLineItem.md#lineitemid)

## Properties

### attributes

• **attributes**: `LineItemAttributesInput`

Payload to update the customer's cart with. This payload matches the one
sent to [Chord OMS's update order line item endpoint](https://chord.stoplight.io/docs/chord-oms/5ca7631abac5c-update-order-line-item).

#### Defined in

[packages/react-autonomy/src/redux/actions/cart/modify-line-item.ts:39](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/cart/modify-line-item.ts#L39)

___

### lineItemId

• **lineItemId**: `number`

#### Defined in

[packages/react-autonomy/src/redux/actions/cart/modify-line-item.ts:34](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/cart/modify-line-item.ts#L34)
