[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / [react-autonomy](../modules/react_autonomy.md) / TrackProductClicked

# Interface: TrackProductClicked

[react-autonomy](../modules/react_autonomy.md).TrackProductClicked

## Table of contents

### Properties

- [product](react_autonomy.TrackProductClicked.md#product)

## Properties

### product

• **product**: [`Product`](react_autonomy.Product.md)

The product the customer clicked.

#### Defined in

[packages/react-autonomy/src/redux/actions/analytics/track-product-clicked.ts:8](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/analytics/track-product-clicked.ts#L8)
