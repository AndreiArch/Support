[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / [react-autonomy](../modules/react_autonomy.md) / ChordProviderProps

# Interface: ChordProviderProps

[react-autonomy](../modules/react_autonomy.md).ChordProviderProps

Props for [ChordProvider](../modules/react_autonomy.md#chordprovider).

## Table of contents

### Properties

- [auth](react_autonomy.ChordProviderProps.md#auth)
- [config](react_autonomy.ChordProviderProps.md#config)
- [middleware](react_autonomy.ChordProviderProps.md#middleware)
- [preloadedState](react_autonomy.ChordProviderProps.md#preloadedstate)
- [reducer](react_autonomy.ChordProviderProps.md#reducer)

## Properties

### auth

• **auth**: [`AuthClient`](react_autonomy.AuthClient.md)

Chord compatible wrapper for an authentication client. [AuthClient](react_autonomy.AuthClient.md)
describes the shape this client must take in order to work with
react-autonomy.

#### Defined in

[packages/react-autonomy/src/provider/index.tsx:37](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/provider/index.tsx#L37)

___

### config

• **config**: `ChordClientConfig`

Configuration variables for Chord. These are provided during provisioning.

#### Defined in

[packages/react-autonomy/src/provider/index.tsx:16](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/provider/index.tsx#L16)

___

### middleware

• `Optional` **middleware**: `Middleware`<{}, `any`, `Dispatch`<`AnyAction`\>\>[]

Redux middlewares. These allow you to extend/modify Chord's core
functionality to your application's needs.

#### Defined in

[packages/react-autonomy/src/provider/index.tsx:21](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/provider/index.tsx#L21)

___

### preloadedState

• `Optional` **preloadedState**: `Record`<`string`, `any`\>

State that you would like loaded into the Redux store.

#### Defined in

[packages/react-autonomy/src/provider/index.tsx:25](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/provider/index.tsx#L25)

___

### reducer

• `Optional` **reducer**: `Object`

Additional Redux reducers to be added to the store.

#### Index signature

▪ [key: `string`]: `Reducer`

#### Defined in

[packages/react-autonomy/src/provider/index.tsx:29](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/provider/index.tsx#L29)
