[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / [react-autonomy](../modules/react_autonomy.md) / Product

# Interface: Product

[react-autonomy](../modules/react_autonomy.md).Product

## Hierarchy

- `Omit`<`Partial`<`LineItem`\>, ``"variant"``\>

  ↳ **`Product`**

## Table of contents

### Properties

- [adjustments](react_autonomy.Product.md#adjustments)
- [displayAmount](react_autonomy.Product.md#displayamount)
- [giftCards](react_autonomy.Product.md#giftcards)
- [id](react_autonomy.Product.md#id)
- [metadata](react_autonomy.Product.md#metadata)
- [price](react_autonomy.Product.md#price)
- [quantity](react_autonomy.Product.md#quantity)
- [singleDisplayAmount](react_autonomy.Product.md#singledisplayamount)
- [subscriptionLineItems](react_autonomy.Product.md#subscriptionlineitems)
- [total](react_autonomy.Product.md#total)
- [variant](react_autonomy.Product.md#variant)
- [variantId](react_autonomy.Product.md#variantid)

## Properties

### adjustments

• `Optional` **adjustments**: [`Adjustment`](react_autonomy.Adjustment.md)[]

#### Inherited from

Omit.adjustments

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:250

___

### displayAmount

• `Optional` **displayAmount**: `string`

#### Inherited from

Omit.displayAmount

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:251

___

### giftCards

• `Optional` **giftCards**: `GiftCard`[]

#### Inherited from

Omit.giftCards

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:252

___

### id

• `Optional` **id**: `number`

#### Inherited from

Omit.id

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:253

___

### metadata

• `Optional` **metadata**: [`Metadata`](../modules/react_autonomy.md#metadata)

#### Inherited from

Omit.metadata

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:254

___

### price

• `Optional` **price**: `string`

#### Inherited from

Omit.price

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:255

___

### quantity

• `Optional` **quantity**: `number`

#### Inherited from

Omit.quantity

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:256

___

### singleDisplayAmount

• `Optional` **singleDisplayAmount**: `string`

#### Inherited from

Omit.singleDisplayAmount

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:257

___

### subscriptionLineItems

• `Optional` **subscriptionLineItems**: `SubscriptionLineItem`[]

#### Inherited from

Omit.subscriptionLineItems

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:258

___

### total

• `Optional` **total**: `string`

#### Inherited from

Omit.total

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:259

___

### variant

• **variant**: `ProductVariant`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/analytics/types/objects.d.ts:26

___

### variantId

• `Optional` **variantId**: `number`

#### Inherited from

Omit.variantId

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:261
