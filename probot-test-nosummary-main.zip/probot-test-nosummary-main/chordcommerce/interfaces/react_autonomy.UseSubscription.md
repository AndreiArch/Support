[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / [react-autonomy](../modules/react_autonomy.md) / UseSubscription

# Interface: UseSubscription

[react-autonomy](../modules/react_autonomy.md).UseSubscription

`UseSubscription` contains all the data and methods returned by the
[useSubscription](../modules/react_autonomy.md#usesubscription) hook.

## Table of contents

### Properties

- [cancelSubscription](react_autonomy.UseSubscription.md#cancelsubscription)
- [error](react_autonomy.UseSubscription.md#error)
- [isFetching](react_autonomy.UseSubscription.md#isfetching)
- [isLoaded](react_autonomy.UseSubscription.md#isloaded)
- [loadSubscription](react_autonomy.UseSubscription.md#loadsubscription)
- [pauseSubscription](react_autonomy.UseSubscription.md#pausesubscription)
- [resumeSubscription](react_autonomy.UseSubscription.md#resumesubscription)
- [skipSubscription](react_autonomy.UseSubscription.md#skipsubscription)
- [subscription](react_autonomy.UseSubscription.md#subscription)
- [updateSubscription](react_autonomy.UseSubscription.md#updatesubscription)

## Properties

### cancelSubscription

• **cancelSubscription**: (`options?`: [`CancelSubscription`](react_autonomy.CancelSubscription.md)) => `Promise`<[`Subscription`](react_autonomy.Subscription.md)\>

#### Type declaration

▸ (`options?`): `Promise`<[`Subscription`](react_autonomy.Subscription.md)\>

The `cancelSubscription` function calls the Chord API to cancel
the subscription.

**`Example`**

```javascript
import { useSubscription } from '@chordcommerce/react-autonomy'

export default subscriptionId => {
  const { subscription, cancelSubscription } = useSubscription({ subscriptionId })

  const onClick = async () => {
    return cancelSubscription()
  }

  return <button onClick={onClick}>Cancel Subscription</button>
}
```

##### Parameters

| Name | Type |
| :------ | :------ |
| `options?` | [`CancelSubscription`](react_autonomy.CancelSubscription.md) |

##### Returns

`Promise`<[`Subscription`](react_autonomy.Subscription.md)\>

#### Defined in

[packages/react-autonomy/src/hooks/use-subscription.ts:205](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-subscription.ts#L205)

___

### error

• **error**: `Error`

#### Defined in

[packages/react-autonomy/src/hooks/use-subscription.ts:122](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-subscription.ts#L122)

___

### isFetching

• **isFetching**: `boolean`

#### Defined in

[packages/react-autonomy/src/hooks/use-subscription.ts:124](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-subscription.ts#L124)

___

### isLoaded

• **isLoaded**: `boolean`

#### Defined in

[packages/react-autonomy/src/hooks/use-subscription.ts:123](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-subscription.ts#L123)

___

### loadSubscription

• **loadSubscription**: () => `Promise`<[`Subscription`](react_autonomy.Subscription.md)\>

#### Type declaration

▸ (): `Promise`<[`Subscription`](react_autonomy.Subscription.md)\>

The `loadSubscription` function loads information about the subscription
from the Chord API.

You shouldn't need to call this function, except in exceptional
circumstances, as the [useSubscription](../modules/react_autonomy.md#usesubscription) hook will automatically start
loading the subscription when the hook is initialized.

**`Example`**

Here's an example of when you might want to use `loadSubscription` in
a custom callback. It should be noted that `skipSubscription` returns the
updated subscription, but in this example, assume that it doesn't for
educational purposes.

```javascript
import { useSubscription } from '@chordcommerce/react-autonomy'
import customEventingFunction from '~/app/events'

const SkipSubscriptionButon = ({ subscriptionId }) => {
  const {
    subscription,
    loadSubscription,
    skipSubscription
  } = useSubscription({ subscriptionId })

  const handleClick = async () =>
    await skipSubscription()
    const updatedSubscription = await loadSubscription()
    await customEventingFunction('Subscription Skipped', {
      newEndDate: updatedSubscription.endDate,
    })
  }

  return <button onClick={handleClick}>Skip</button>
}
```

##### Returns

`Promise`<[`Subscription`](react_autonomy.Subscription.md)\>

#### Defined in

[packages/react-autonomy/src/hooks/use-subscription.ts:163](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-subscription.ts#L163)

___

### pauseSubscription

• **pauseSubscription**: (`options`: [`PauseSubscription`](react_autonomy.PauseSubscription.md)) => `Promise`<[`Subscription`](react_autonomy.Subscription.md)\>

#### Type declaration

▸ (`options`): `Promise`<[`Subscription`](react_autonomy.Subscription.md)\>

The `pauseSubscription` function calls the Chord API to pause
a subscription.

**`Example`**

```javascript
import { useSubscription } from '@chordcommerce/react-autonomy'

export default subscriptionId => {
  const { subscription, pauseSubscription } = useSubscription({ subscriptionId })

  const onClick = async () => {
    return pauseSubscription({ actionableDate: new Date().toISOString() })
  }

  return <button onClick={onClick}>Pause Subscription</button>
}
```

##### Parameters

| Name | Type |
| :------ | :------ |
| `options` | [`PauseSubscription`](react_autonomy.PauseSubscription.md) |

##### Returns

`Promise`<[`Subscription`](react_autonomy.Subscription.md)\>

#### Defined in

[packages/react-autonomy/src/hooks/use-subscription.ts:271](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-subscription.ts#L271)

___

### resumeSubscription

• **resumeSubscription**: (`options`: [`ResumeSubscription`](react_autonomy.ResumeSubscription.md)) => `Promise`<[`Subscription`](react_autonomy.Subscription.md)\>

#### Type declaration

▸ (`options`): `Promise`<[`Subscription`](react_autonomy.Subscription.md)\>

The `resumeSubscription` function calls the Chord API to resume
a subscription.

Paused subscriptions will not be processed until manually `resumed` or the
`actionableDate` is reached.

**`Example`**

```javascript
import { useSubscription } from '@chordcommerce/react-autonomy'

export default subscriptionId => {
  const { subscription, resumeSubscription } = useSubscription({ subscriptionId })

  const onClick = async () => {
    return resumeSubscription({ actionableDate: new Date().toISOString() })
  }

  return <button onClick={onClick}>Resume Subscription</button>
}
```

##### Parameters

| Name | Type |
| :------ | :------ |
| `options` | [`ResumeSubscription`](react_autonomy.ResumeSubscription.md) |

##### Returns

`Promise`<[`Subscription`](react_autonomy.Subscription.md)\>

#### Defined in

[packages/react-autonomy/src/hooks/use-subscription.ts:295](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-subscription.ts#L295)

___

### skipSubscription

• **skipSubscription**: (`options?`: [`SkipSubscription`](react_autonomy.SkipSubscription.md)) => `Promise`<[`Subscription`](react_autonomy.Subscription.md)\>

#### Type declaration

▸ (`options?`): `Promise`<[`Subscription`](react_autonomy.Subscription.md)\>

The `skipSubscription` function calls the Chord API to skip the next
subscription delivery.

**`Example`**

```javascript
import { useSubscription } from '@chordcommerce/react-autonomy'

export default subscriptionId => {
  const { subscription, skipSubscription } = useSubscription({ subscriptionId })

  const onClick = () => {
    skipSubscription()
  }

  return <button onClick={onClick}>Skip Next Shipment</button>
}
```

##### Parameters

| Name | Type |
| :------ | :------ |
| `options?` | [`SkipSubscription`](react_autonomy.SkipSubscription.md) |

##### Returns

`Promise`<[`Subscription`](react_autonomy.Subscription.md)\>

#### Defined in

[packages/react-autonomy/src/hooks/use-subscription.ts:184](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-subscription.ts#L184)

___

### subscription

• **subscription**: [`Subscription`](react_autonomy.Subscription.md)

#### Defined in

[packages/react-autonomy/src/hooks/use-subscription.ts:121](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-subscription.ts#L121)

___

### updateSubscription

• **updateSubscription**: (`options`: [`SubscriptionUpdateProps`](react_autonomy.SubscriptionUpdateProps.md)) => `Promise`<[`Subscription`](react_autonomy.Subscription.md)\>

#### Type declaration

▸ (`options`): `Promise`<[`Subscription`](react_autonomy.Subscription.md)\>

The `updateSubscription` function calls the Chord API to update
a subscription.

**`Example`**

```javascript
import { useSubscription } from '@chordcommerce/react-autonomy'

export default () => {
  const { updateSubscription } = useSubscription(subscription.id)
  const onSubmit = async data => {
    try {
      let response = await updateSubscription({
        shipAddressAttributes: data.addressAttributes,
        billAddressAttributes: data.addressAttributes,
        intervalLength: 2,
        intervalUnits: 'month',
        endDate: '2021-12-31',
        actionableDate: '2030-08-18'
      })
      console.log(response)
    } catch (error) {
      console.error(error)
    }
  }
}

// Default Form Values:

const address = subscription['shipAddress']
const addressAttributes = {
  name: address.name,
  address1: address.address1,
  address2: address.address2,
  city: address.city,
  state_name: address.state.abbr,
  country_iso: address.country.iso,
  zipcode: address.zipcode
}
```

##### Parameters

| Name | Type |
| :------ | :------ |
| `options` | [`SubscriptionUpdateProps`](react_autonomy.SubscriptionUpdateProps.md) |

##### Returns

`Promise`<[`Subscription`](react_autonomy.Subscription.md)\>

#### Defined in

[packages/react-autonomy/src/hooks/use-subscription.ts:248](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-subscription.ts#L248)
