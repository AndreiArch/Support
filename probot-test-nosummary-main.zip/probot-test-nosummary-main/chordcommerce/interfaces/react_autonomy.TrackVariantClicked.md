[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / [react-autonomy](../modules/react_autonomy.md) / TrackVariantClicked

# Interface: TrackVariantClicked

[react-autonomy](../modules/react_autonomy.md).TrackVariantClicked

## Table of contents

### Properties

- [product](react_autonomy.TrackVariantClicked.md#product)

## Properties

### product

• **product**: [`Product`](react_autonomy.Product.md)

#### Defined in

[packages/react-autonomy/src/redux/actions/analytics/track-variant-clicked.ts:5](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/analytics/track-variant-clicked.ts#L5)
