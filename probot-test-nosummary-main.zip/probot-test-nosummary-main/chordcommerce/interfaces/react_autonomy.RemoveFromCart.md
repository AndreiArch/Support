[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / [react-autonomy](../modules/react_autonomy.md) / RemoveFromCart

# Interface: RemoveFromCart

[react-autonomy](../modules/react_autonomy.md).RemoveFromCart

## Table of contents

### Properties

- [lineItemId](react_autonomy.RemoveFromCart.md#lineitemid)
- [product](react_autonomy.RemoveFromCart.md#product)

## Properties

### lineItemId

• **lineItemId**: `number`

#### Defined in

[packages/react-autonomy/src/redux/actions/cart/remove-from-cart.ts:48](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/cart/remove-from-cart.ts#L48)

___

### product

• `Optional` **product**: [`Product`](react_autonomy.Product.md)

#### Defined in

[packages/react-autonomy/src/redux/actions/cart/remove-from-cart.ts:49](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/cart/remove-from-cart.ts#L49)
