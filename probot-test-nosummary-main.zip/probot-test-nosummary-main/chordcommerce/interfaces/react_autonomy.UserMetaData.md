[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / [react-autonomy](../modules/react_autonomy.md) / UserMetaData

# Interface: UserMetaData

[react-autonomy](../modules/react_autonomy.md).UserMetaData

## Table of contents

### Properties

- [email](react_autonomy.UserMetaData.md#email)
- [issuer](react_autonomy.UserMetaData.md#issuer)
- [phoneNumber](react_autonomy.UserMetaData.md#phonenumber)
- [publicAddress](react_autonomy.UserMetaData.md#publicaddress)

## Properties

### email

• **email**: `string`

#### Defined in

[packages/react-autonomy/src/types.ts:7](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/types.ts#L7)

___

### issuer

• `Optional` **issuer**: `string`

#### Defined in

[packages/react-autonomy/src/types.ts:8](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/types.ts#L8)

___

### phoneNumber

• `Optional` **phoneNumber**: `string`

#### Defined in

[packages/react-autonomy/src/types.ts:10](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/types.ts#L10)

___

### publicAddress

• `Optional` **publicAddress**: `string`

#### Defined in

[packages/react-autonomy/src/types.ts:9](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/types.ts#L9)
