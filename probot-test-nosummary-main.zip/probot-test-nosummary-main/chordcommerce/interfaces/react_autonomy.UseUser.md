[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / [react-autonomy](../modules/react_autonomy.md) / UseUser

# Interface: UseUser

[react-autonomy](../modules/react_autonomy.md).UseUser

UseUser contains the data and methods returned by the [useUser](../modules/react_autonomy.md#useuser) hook.

## Table of contents

### Properties

- [loadUser](react_autonomy.UseUser.md#loaduser)
- [loadUserReferralIdentifier](react_autonomy.UseUser.md#loaduserreferralidentifier)
- [modifyUser](react_autonomy.UseUser.md#modifyuser)
- [user](react_autonomy.UseUser.md#user)

## Properties

### loadUser

• **loadUser**: () => `Promise`<`void`\>

#### Type declaration

▸ (): `Promise`<`void`\>

The `loadUser` function loads information about the current order's
associated user from the Chord API.

You probably will not need to call this function, as [useUser](../modules/react_autonomy.md#useuser) will
automatically load the user, if needed.

**`Example`**

```javascript
import { useUser } from '@chordcommerce/react-autonomy'

export default () => {
  const { user, loadUser } = useUser()

  useEffect(() => {
    loadUser()
  }, [])

  return <p>Welcome, {user.data.email}!</p>
}
```

##### Returns

`Promise`<`void`\>

A Promise that resolves when the `user` object has been added to
Redux.

#### Defined in

[packages/react-autonomy/src/hooks/use-user.ts:122](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-user.ts#L122)

___

### loadUserReferralIdentifier

• **loadUserReferralIdentifier**: (`options`: [`LoadUserReferralIdentifier`](../modules/react_autonomy.md#loaduserreferralidentifier)) => `Promise`<[`ReferralIdentifier`](react_autonomy.ReferralIdentifier.md)\>

#### Type declaration

▸ (`options`): `Promise`<[`ReferralIdentifier`](react_autonomy.ReferralIdentifier.md)\>

The `loadUserReferralIdentifier` function loads the referral identifier
information for a user with the given email address from the Chord API.

**`Example`**

```javascript
import { useUser } from '@chordcommerce/react-autonomy'

export default () => {
  const { user, loadUserReferralIdentifier } = useUser()
  const referralPurl = user.referralIdentifier && user.referralIdentifier.purl

  useEffect(() => {
    loadUserReferralIdentifier()
  }, [])

  return (
    <p>Refer your friends with your personal referral link: {referralPurl}</p>
  )
}
```

##### Parameters

| Name | Type |
| :------ | :------ |
| `options` | [`LoadUserReferralIdentifier`](../modules/react_autonomy.md#loaduserreferralidentifier) |

##### Returns

`Promise`<[`ReferralIdentifier`](react_autonomy.ReferralIdentifier.md)\>

A Promise that resolves when the `referralIdentifier` object has
been added to the `user` object in Redux.

#### Defined in

[packages/react-autonomy/src/hooks/use-user.ts:149](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-user.ts#L149)

___

### modifyUser

• **modifyUser**: (`options`: [`ModifyUser`](../modules/react_autonomy.md#modifyuser)) => `Promise`<`void`\>

#### Type declaration

▸ (`options`): `Promise`<`void`\>

The `modifyUser` function is used to update the user's profile information.

**`Example`**

```javascript
import { useUser } from '@chordcommerce/react-autonomy'

export const AccountPage => {
  const { modifyUser } = useUser()
  const onSubmit = ({ email }) => {
    modifyUser({ email })
  }

  // return profile edit form
}
```

##### Parameters

| Name | Type |
| :------ | :------ |
| `options` | [`ModifyUser`](../modules/react_autonomy.md#modifyuser) |

##### Returns

`Promise`<`void`\>

A Promise that resolves when the `user` object has been updated in
Redux.

#### Defined in

[packages/react-autonomy/src/hooks/use-user.ts:173](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-user.ts#L173)

___

### user

• **user**: `any`

#### Defined in

[packages/react-autonomy/src/hooks/use-user.ts:95](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-user.ts#L95)
