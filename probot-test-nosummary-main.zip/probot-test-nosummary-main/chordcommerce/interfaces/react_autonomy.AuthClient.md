[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / [react-autonomy](../modules/react_autonomy.md) / AuthClient

# Interface: AuthClient

[react-autonomy](../modules/react_autonomy.md).AuthClient

## Table of contents

### Properties

- [client](react_autonomy.AuthClient.md#client)
- [getToken](react_autonomy.AuthClient.md#gettoken)
- [getUser](react_autonomy.AuthClient.md#getuser)
- [handleCallback](react_autonomy.AuthClient.md#handlecallback)
- [isLoggedIn](react_autonomy.AuthClient.md#isloggedin)
- [login](react_autonomy.AuthClient.md#login)
- [logout](react_autonomy.AuthClient.md#logout)

## Properties

### client

• **client**: `any`

#### Defined in

[packages/react-autonomy/src/types.ts:14](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/types.ts#L14)

___

### getToken

• **getToken**: () => `Promise`<`string`\>

#### Type declaration

▸ (): `Promise`<`string`\>

##### Returns

`Promise`<`string`\>

#### Defined in

[packages/react-autonomy/src/types.ts:15](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/types.ts#L15)

___

### getUser

• **getUser**: () => `Promise`<[`UserMetaData`](react_autonomy.UserMetaData.md)\>

#### Type declaration

▸ (): `Promise`<[`UserMetaData`](react_autonomy.UserMetaData.md)\>

##### Returns

`Promise`<[`UserMetaData`](react_autonomy.UserMetaData.md)\>

#### Defined in

[packages/react-autonomy/src/types.ts:16](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/types.ts#L16)

___

### handleCallback

• **handleCallback**: `any`

#### Defined in

[packages/react-autonomy/src/types.ts:20](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/types.ts#L20)

___

### isLoggedIn

• **isLoggedIn**: () => `Promise`<`boolean`\>

#### Type declaration

▸ (): `Promise`<`boolean`\>

##### Returns

`Promise`<`boolean`\>

#### Defined in

[packages/react-autonomy/src/types.ts:17](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/types.ts#L17)

___

### login

• **login**: (`props`: `any`) => `Promise`<`void`\>

#### Type declaration

▸ (`props`): `Promise`<`void`\>

##### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `any` |

##### Returns

`Promise`<`void`\>

#### Defined in

[packages/react-autonomy/src/types.ts:18](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/types.ts#L18)

___

### logout

• **logout**: () => `Promise`<`void`\>

#### Type declaration

▸ (): `Promise`<`void`\>

##### Returns

`Promise`<`void`\>

#### Defined in

[packages/react-autonomy/src/types.ts:19](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/types.ts#L19)
