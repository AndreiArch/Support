[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / [react-autonomy](../modules/react_autonomy.md) / ModifyCart

# Interface: ModifyCart

[react-autonomy](../modules/react_autonomy.md).ModifyCart

## Table of contents

### Properties

- [attributes](react_autonomy.ModifyCart.md#attributes)

## Properties

### attributes

• **attributes**: `OrderInput`

An object to send to the [Chord OMS update order endpoint](https://chord.stoplight.io/docs/chord-oms/b3A6MTE3Nzk0Mjk-update-order).

#### Defined in

[packages/react-autonomy/src/redux/actions/cart/modify-cart.ts:38](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/cart/modify-cart.ts#L38)
