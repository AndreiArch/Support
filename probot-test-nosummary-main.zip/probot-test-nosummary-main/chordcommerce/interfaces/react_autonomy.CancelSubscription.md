[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / [react-autonomy](../modules/react_autonomy.md) / CancelSubscription

# Interface: CancelSubscription

[react-autonomy](../modules/react_autonomy.md).CancelSubscription

## Table of contents

### Properties

- [products](react_autonomy.CancelSubscription.md#products)

## Properties

### products

• `Optional` **products**: [`Product`](react_autonomy.Product.md)[]

#### Defined in

[packages/react-autonomy/src/redux/actions/subscriptions/cancel-subscription.ts:36](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/subscriptions/cancel-subscription.ts#L36)
