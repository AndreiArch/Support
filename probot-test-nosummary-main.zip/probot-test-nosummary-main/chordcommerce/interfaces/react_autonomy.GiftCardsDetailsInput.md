[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / [react-autonomy](../modules/react_autonomy.md) / GiftCardsDetailsInput

# Interface: GiftCardsDetailsInput

[react-autonomy](../modules/react_autonomy.md).GiftCardsDetailsInput

## Table of contents

### Properties

- [giftMessage](react_autonomy.GiftCardsDetailsInput.md#giftmessage)
- [id](react_autonomy.GiftCardsDetailsInput.md#id)
- [recipientEmail](react_autonomy.GiftCardsDetailsInput.md#recipientemail)
- [recipientName](react_autonomy.GiftCardsDetailsInput.md#recipientname)
- [sendEmailAt](react_autonomy.GiftCardsDetailsInput.md#sendemailat)

## Properties

### giftMessage

• `Optional` **giftMessage**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/inputs.d.ts:280

___

### id

• **id**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/inputs.d.ts:281

___

### recipientEmail

• `Optional` **recipientEmail**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/inputs.d.ts:278

___

### recipientName

• `Optional` **recipientName**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/inputs.d.ts:279

___

### sendEmailAt

• `Optional` **sendEmailAt**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/inputs.d.ts:277
