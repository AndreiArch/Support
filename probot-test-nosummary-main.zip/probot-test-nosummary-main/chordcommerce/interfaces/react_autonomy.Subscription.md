[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / [react-autonomy](../modules/react_autonomy.md) / Subscription

# Interface: Subscription

[react-autonomy](../modules/react_autonomy.md).Subscription

## Table of contents

### Properties

- [actionableDate](react_autonomy.Subscription.md#actionabledate)
- [billAddress](react_autonomy.Subscription.md#billaddress)
- [createdAt](react_autonomy.Subscription.md#createdat)
- [endDate](react_autonomy.Subscription.md#enddate)
- [id](react_autonomy.Subscription.md#id)
- [interval](react_autonomy.Subscription.md#interval)
- [intervalLength](react_autonomy.Subscription.md#intervallength)
- [intervalUnits](react_autonomy.Subscription.md#intervalunits)
- [lineItems](react_autonomy.Subscription.md#lineitems)
- [shipAddress](react_autonomy.Subscription.md#shipaddress)
- [state](react_autonomy.Subscription.md#state)

## Properties

### actionableDate

• **actionableDate**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:389

___

### billAddress

• **billAddress**: `Address`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:394

___

### createdAt

• **createdAt**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:388

___

### endDate

• **endDate**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:393

___

### id

• **id**: `number`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:386

___

### interval

• **interval**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:392

___

### intervalLength

• **intervalLength**: `number`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:390

___

### intervalUnits

• **intervalUnits**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:391

___

### lineItems

• **lineItems**: `SubscriptionLineItem`[]

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:396

___

### shipAddress

• **shipAddress**: `Address`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:395

___

### state

• **state**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:387
