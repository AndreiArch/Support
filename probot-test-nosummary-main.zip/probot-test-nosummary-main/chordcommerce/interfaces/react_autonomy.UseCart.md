[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / [react-autonomy](../modules/react_autonomy.md) / UseCart

# Interface: UseCart

[react-autonomy](../modules/react_autonomy.md).UseCart

`UseCart` contains the data and methods returned by the [useCart](../modules/react_autonomy.md#usecart) hook.

## Hierarchy

- `Omit`<`RootInitialState`[``"cart"``], ``"data"``\>

  ↳ **`UseCart`**

## Table of contents

### Properties

- [addCrossSell](react_autonomy.UseCart.md#addcrosssell)
- [addPromoCode](react_autonomy.UseCart.md#addpromocode)
- [addSubscription](react_autonomy.UseCart.md#addsubscription)
- [addToCart](react_autonomy.UseCart.md#addtocart)
- [cart](react_autonomy.UseCart.md#cart)
- [error](react_autonomy.UseCart.md#error)
- [forgetCart](react_autonomy.UseCart.md#forgetcart)
- [isFetching](react_autonomy.UseCart.md#isfetching)
- [isLoaded](react_autonomy.UseCart.md#isloaded)
- [loadCart](react_autonomy.UseCart.md#loadcart)
- [modifyCart](react_autonomy.UseCart.md#modifycart)
- [modifyGiftCards](react_autonomy.UseCart.md#modifygiftcards)
- [modifyLineItem](react_autonomy.UseCart.md#modifylineitem)
- [promoCode](react_autonomy.UseCart.md#promocode)
- [removeFromCart](react_autonomy.UseCart.md#removefromcart)
- [removePromoCode](react_autonomy.UseCart.md#removepromocode)

## Properties

### addCrossSell

• **addCrossSell**: (`options`: [`CrossSell`](react_autonomy.CrossSell.md)) => `Promise`<[`OrderBig`](react_autonomy.OrderBig.md)\>

#### Type declaration

▸ (`options`): `Promise`<[`OrderBig`](react_autonomy.OrderBig.md)\>

The `addCrossSell` function takes an array of line items post-checkout and
adds them to the order, charging the card again in the process.

**`Example`**

```javascript
import { useCart } from '@chordcommerce/react-autonomy'

const CrossSellCheckoutButton = ({ orderID, orderToken, lineItemsAttributes }) => {
  const { addCrossSell } = useCart()

  const purchaseCrossSells = async () => addCrossSell({
    lineItemsAttributes,
    cart: {
      number: orderID,
      token: orderToken,
    },
  })

  return <button onClick={purchaseCrossSells}>Buy</button>
}
```

##### Parameters

| Name | Type |
| :------ | :------ |
| `options` | [`CrossSell`](react_autonomy.CrossSell.md) |

##### Returns

`Promise`<[`OrderBig`](react_autonomy.OrderBig.md)\>

#### Defined in

[packages/react-autonomy/src/hooks/use-cart.ts:138](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-cart.ts#L138)

___

### addPromoCode

• **addPromoCode**: (`options`: [`AddPromoCode`](../modules/react_autonomy.md#addpromocode)) => `Promise`<`void`\>

#### Type declaration

▸ (`options`): `Promise`<`void`\>

The `addPromoCode` function applies a promo code to the current shopping
cart.

**`Example`**

```javascript
import { useCart } from '@chordcommerce/react-autonomy'

const PromoCodeForm = () => {
  const { cart, addPromoCode } = useCart()
  const onSubmit = async ({ promoCode }) => {
    try {
      await addPromoCode(promoCode)
    } catch(error) {
      console.error('Error applying promo code.')
    }
  }
}
```

##### Parameters

| Name | Type |
| :------ | :------ |
| `options` | [`AddPromoCode`](../modules/react_autonomy.md#addpromocode) |

##### Returns

`Promise`<`void`\>

#### Defined in

[packages/react-autonomy/src/hooks/use-cart.ts:160](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-cart.ts#L160)

___

### addSubscription

• **addSubscription**: (`subscription`: [`AddSubscriptionItem`](../modules/react_autonomy.md#addsubscriptionitem)) => `Promise`<`void`\>

#### Type declaration

▸ (`subscription`): `Promise`<`void`\>

The `addSubscription` function adds a subscription item to the customer's
cart.

**`Example`**

```javascript
import { useCart } from '@chordcommerce/react-autonomy'

const AddSubscriptionToCartButton = ({
  sku,
  quantity,
  endDate,
  intervalUnit,
  intervalLength,
}) => {
  const { addSubscription } = useCart()

  const addToCart = async () => addSubscription({
    sku,
    quantity,
    endDate,
    interval: {
      length: intervalLength,
      unit: intervalUnit,
    },
  })

  return <button onClick={addToCart}>Add To Cart</button>
}
```

##### Parameters

| Name | Type |
| :------ | :------ |
| `subscription` | [`AddSubscriptionItem`](../modules/react_autonomy.md#addsubscriptionitem) |

##### Returns

`Promise`<`void`\>

#### Defined in

[packages/react-autonomy/src/hooks/use-cart.ts:193](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-cart.ts#L193)

___

### addToCart

• **addToCart**: (`items`: [`AddToCartItem`](../modules/react_autonomy.md#addtocartitem) \| [`AddToCartItem`](../modules/react_autonomy.md#addtocartitem)[]) => `Promise`<`void`\>

#### Type declaration

▸ (`items`): `Promise`<`void`\>

The `addToCart` function adds a product variant to the current shopping cart
(creating a line item).

**`Example`**

```javascript
import { useCart } from '@chordcommerce/react-autonomy'

export default () => {
  const { addToCart } = useCart()
  const onSubmit = ({ sku, quantity }) => {
    addToCart({ sku, quantity })
  }
}
```

##### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `items` | [`AddToCartItem`](../modules/react_autonomy.md#addtocartitem) \| [`AddToCartItem`](../modules/react_autonomy.md#addtocartitem)[] | The items to add to the cart. |

##### Returns

`Promise`<`void`\>

A Promise that resolves once the items are added to the cart.

#### Defined in

[packages/react-autonomy/src/hooks/use-cart.ts:213](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-cart.ts#L213)

___

### cart

• **cart**: `Partial`<[`OrderBig`](react_autonomy.OrderBig.md)\>

An object representing the current shopping cart.

#### Defined in

[packages/react-autonomy/src/hooks/use-cart.ts:113](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-cart.ts#L113)

___

### error

• **error**: `Error`

#### Inherited from

Omit.error

#### Defined in

[packages/react-autonomy/src/redux/store/initial-state.ts:41](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/store/initial-state.ts#L41)

___

### forgetCart

• **forgetCart**: () => { `type`: `string` = FORGET\_CART }

#### Type declaration

▸ (): `Object`

The `forgetCart` function clears the customer's cart.

##### Returns

`Object`

| Name | Type |
| :------ | :------ |
| `type` | `string` |

#### Defined in

[packages/react-autonomy/src/hooks/use-cart.ts:217](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-cart.ts#L217)

___

### isFetching

• **isFetching**: `boolean`

#### Inherited from

Omit.isFetching

#### Defined in

[packages/react-autonomy/src/redux/store/initial-state.ts:39](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/store/initial-state.ts#L39)

___

### isLoaded

• **isLoaded**: `boolean`

#### Inherited from

Omit.isLoaded

#### Defined in

[packages/react-autonomy/src/redux/store/initial-state.ts:40](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/store/initial-state.ts#L40)

___

### loadCart

• **loadCart**: () => `Promise`<`void`\>

#### Type declaration

▸ (): `Promise`<`void`\>

The `loadCart` function loads the current cart based on the current browser
session and populates the cart in Redux. `loadCart` is automatically called
on page load.

**`Example`**

```javascript
import { useCart } from '@chordcommerce/react-autonomy'

export default () => {
  const { cart, loadCart } = useCart()

  useEffect(() => {
    loadCart().catch(error => {
      console.error(error.message)
    })
  }, [loadCart])
}
```

##### Returns

`Promise`<`void`\>

A Promise that resolves when the cart object has been added to Redux.

#### Defined in

[packages/react-autonomy/src/hooks/use-cart.ts:240](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-cart.ts#L240)

___

### modifyCart

• **modifyCart**: (`options`: [`ModifyCart`](react_autonomy.ModifyCart.md)) => `Promise`<`void`\>

#### Type declaration

▸ (`options`): `Promise`<`void`\>

The `modifyCart` function modifies the current cart. It sends it's payload
to the [Chord OMS update order endpoint](https://chord.stoplight.io/docs/chord-oms/b3A6MTE3Nzk0Mjk-update-order).

##### Parameters

| Name | Type |
| :------ | :------ |
| `options` | [`ModifyCart`](react_autonomy.ModifyCart.md) |

##### Returns

`Promise`<`void`\>

A Promise that resolves when the `cart` object has been updated in
Redux.

#### Defined in

[packages/react-autonomy/src/hooks/use-cart.ts:248](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-cart.ts#L248)

___

### modifyGiftCards

• **modifyGiftCards**: (`options`: [`GiftCardsInput`](react_autonomy.GiftCardsInput.md)) => `Promise`<`void`\>

#### Type declaration

▸ (`options`): `Promise`<`void`\>

The `modifyGiftCards` function applies or removes gift cards from the current
cart.

The `giftCardsDetails` object is returned in the `lineItem` object if the
`lineItem` is a gift card. Additionally, newly redeemed gift cards are
available in the `user` object for indicating to the user that they have
received a gift.

The gift cards can be updated by including the gift card `id` along with any
of the following params: `recipientName, recipientEmail, giftMessage,
purchaserName, sendEmailAt.`The recipient email is a required field as that
will be the account used to redeem the gift cards.

**`Example`**

```javascript
import { useCart } from '@chordcommerce/react-autonomy'

export default () => {
  const { modifyGiftCards } = useCart()
  const onSubmit = (event) => {
    modifyGiftCards({
      giftCardsDetails: [
        {
          recipientEmail: "test@chord.co",
          giftMessage: "Hi!",
          sendEmailAt: "2021-11-15",
          id: "49"
        },
        {
          recipientEmail: "admin@chord.co",
          giftMessage: "",
          sendEmailAt: "2021-11-16",
          id: "50"
        }
      ]
    })
  }
}
```

##### Parameters

| Name | Type |
| :------ | :------ |
| `options` | [`GiftCardsInput`](react_autonomy.GiftCardsInput.md) |

##### Returns

`Promise`<`void`\>

A Promise that resolves when the `cart` object has been updated in
Redux.

#### Defined in

[packages/react-autonomy/src/hooks/use-cart.ts:300](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-cart.ts#L300)

___

### modifyLineItem

• **modifyLineItem**: (`options`: [`ModifyLineItem`](react_autonomy.ModifyLineItem.md)) => `Promise`<`void`\>

#### Type declaration

▸ (`options`): `Promise`<`void`\>

The `modifyLineItem` function updates a line item in the customer's cart.
It calls [Chord OMS's update order line item endpoint](https://chord.stoplight.io/docs/chord-oms/5ca7631abac5c-update-order-line-item).

##### Parameters

| Name | Type |
| :------ | :------ |
| `options` | [`ModifyLineItem`](react_autonomy.ModifyLineItem.md) |

##### Returns

`Promise`<`void`\>

A promise that resolves when the cart has been updated in Redux.

#### Defined in

[packages/react-autonomy/src/hooks/use-cart.ts:255](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-cart.ts#L255)

___

### promoCode

• **promoCode**: `Object`

#### Type declaration

| Name | Type |
| :------ | :------ |
| `isFetching` | `boolean` |

#### Inherited from

Omit.promoCode

#### Defined in

[packages/react-autonomy/src/redux/store/initial-state.ts:42](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/store/initial-state.ts#L42)

___

### removeFromCart

• **removeFromCart**: (`options`: [`RemoveFromCart`](react_autonomy.RemoveFromCart.md)) => `Promise`<`void`\>

#### Type declaration

▸ (`options`): `Promise`<`void`\>

The `removeFromCart` function removes a line item from the cart.

##### Parameters

| Name | Type |
| :------ | :------ |
| `options` | [`RemoveFromCart`](react_autonomy.RemoveFromCart.md) |

##### Returns

`Promise`<`void`\>

A Promise that resolves when the `cart` object has been updated in
Redux.

#### Defined in

[packages/react-autonomy/src/hooks/use-cart.ts:307](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-cart.ts#L307)

___

### removePromoCode

• **removePromoCode**: (`options`: [`RemovePromoCode`](react_autonomy.RemovePromoCode.md)) => `Promise`<`void`\>

#### Type declaration

▸ (`options`): `Promise`<`void`\>

The `removePromoCode` function removes an applied promo code from the cart.

##### Parameters

| Name | Type |
| :------ | :------ |
| `options` | [`RemovePromoCode`](react_autonomy.RemovePromoCode.md) |

##### Returns

`Promise`<`void`\>

A Promise that resolves when the `cart` object has been updated in
Redux.

#### Defined in

[packages/react-autonomy/src/hooks/use-cart.ts:314](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-cart.ts#L314)
