[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / [react-autonomy](../modules/react_autonomy.md) / EmailCapture

# Interface: EmailCapture

[react-autonomy](../modules/react_autonomy.md).EmailCapture

## Table of contents

### Properties

- [component](react_autonomy.EmailCapture.md#component)
- [email](react_autonomy.EmailCapture.md#email)
- [page](react_autonomy.EmailCapture.md#page)
- [website](react_autonomy.EmailCapture.md#website)

## Properties

### component

• `Optional` **component**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/analytics/types/objects.d.ts:9

___

### email

• `Optional` **email**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/analytics/types/objects.d.ts:10

___

### page

• `Optional` **page**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/analytics/types/objects.d.ts:11

___

### website

• `Optional` **website**: `string`

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/analytics/types/objects.d.ts:12
