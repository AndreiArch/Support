[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / [react-autonomy](../modules/react_autonomy.md) / CreateStockRequest

# Interface: CreateStockRequest

[react-autonomy](../modules/react_autonomy.md).CreateStockRequest

## Table of contents

### Properties

- [email](react_autonomy.CreateStockRequest.md#email)
- [product](react_autonomy.CreateStockRequest.md#product)

## Properties

### email

• **email**: `string`

The email address to sent an email to when the variant is back in stock.

#### Defined in

[packages/react-autonomy/src/redux/actions/product/create-stock-request.ts:38](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/product/create-stock-request.ts#L38)

___

### product

• **product**: [`Product`](react_autonomy.Product.md)

The product to notify the user about, once it's back in stock.

#### Defined in

[packages/react-autonomy/src/redux/actions/product/create-stock-request.ts:42](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/product/create-stock-request.ts#L42)
