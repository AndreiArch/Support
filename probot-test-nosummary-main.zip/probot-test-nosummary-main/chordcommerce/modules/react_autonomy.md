[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / react-autonomy

# Module: react-autonomy

## Table of contents

### Enumerations

- [AuthErrorCodes](../enums/react_autonomy.AuthErrorCodes.md)

### Hook Interfaces

- [UseAnalytics](../interfaces/react_autonomy.UseAnalytics.md)
- [UseAuth](../interfaces/react_autonomy.UseAuth.md)
- [UseCart](../interfaces/react_autonomy.UseCart.md)
- [UseProduct](../interfaces/react_autonomy.UseProduct.md)
- [UseSubscription](../interfaces/react_autonomy.UseSubscription.md)
- [UseSubscriptions](../interfaces/react_autonomy.UseSubscriptions.md)
- [UseUser](../interfaces/react_autonomy.UseUser.md)

### Other Interfaces

- [Adjustment](../interfaces/react_autonomy.Adjustment.md)
- [AuthClient](../interfaces/react_autonomy.AuthClient.md)
- [CancelSubscription](../interfaces/react_autonomy.CancelSubscription.md)
- [ChordProviderProps](../interfaces/react_autonomy.ChordProviderProps.md)
- [Collection](../interfaces/react_autonomy.Collection.md)
- [CreateStockRequest](../interfaces/react_autonomy.CreateStockRequest.md)
- [CrossSell](../interfaces/react_autonomy.CrossSell.md)
- [EmailCapture](../interfaces/react_autonomy.EmailCapture.md)
- [GiftCardsDetailsInput](../interfaces/react_autonomy.GiftCardsDetailsInput.md)
- [GiftCardsInput](../interfaces/react_autonomy.GiftCardsInput.md)
- [ModifyCart](../interfaces/react_autonomy.ModifyCart.md)
- [ModifyLineItem](../interfaces/react_autonomy.ModifyLineItem.md)
- [OrderBig](../interfaces/react_autonomy.OrderBig.md)
- [PauseSubscription](../interfaces/react_autonomy.PauseSubscription.md)
- [Product](../interfaces/react_autonomy.Product.md)
- [ReferralIdentifier](../interfaces/react_autonomy.ReferralIdentifier.md)
- [RemoveFromCart](../interfaces/react_autonomy.RemoveFromCart.md)
- [RemovePromoCode](../interfaces/react_autonomy.RemovePromoCode.md)
- [ResumeSubscription](../interfaces/react_autonomy.ResumeSubscription.md)
- [SkipSubscription](../interfaces/react_autonomy.SkipSubscription.md)
- [Subscription](../interfaces/react_autonomy.Subscription.md)
- [SubscriptionUpdateProps](../interfaces/react_autonomy.SubscriptionUpdateProps.md)
- [TrackEmailCaptured](../interfaces/react_autonomy.TrackEmailCaptured.md)
- [TrackProductClicked](../interfaces/react_autonomy.TrackProductClicked.md)
- [TrackVariantClicked](../interfaces/react_autonomy.TrackVariantClicked.md)
- [UserMetaData](../interfaces/react_autonomy.UserMetaData.md)

### Type Aliases

- [AddPromoCode](react_autonomy.md#addpromocode)
- [AddSubscriptionItem](react_autonomy.md#addsubscriptionitem)
- [AddToCartItem](react_autonomy.md#addtocartitem)
- [Config](react_autonomy.md#config)
- [IntervalUnit](react_autonomy.md#intervalunit)
- [LoadUserReferralIdentifier](react_autonomy.md#loaduserreferralidentifier)
- [Login](react_autonomy.md#login)
- [Metadata](react_autonomy.md#metadata)
- [ModifyGiftCards](react_autonomy.md#modifygiftcards)
- [ModifyUser](react_autonomy.md#modifyuser)
- [SubscriptionAddress](react_autonomy.md#subscriptionaddress)
- [SubscriptionPaymentSource](react_autonomy.md#subscriptionpaymentsource)
- [TrackCartViewed](react_autonomy.md#trackcartviewed)
- [TrackCollectionClicked](react_autonomy.md#trackcollectionclicked)
- [TrackProductViewed](react_autonomy.md#trackproductviewed)

### Hook Functions

- [useAnalytics](react_autonomy.md#useanalytics)
- [useAuth](react_autonomy.md#useauth)
- [useCart](react_autonomy.md#usecart)
- [useProduct](react_autonomy.md#useproduct)
- [useSubscription](react_autonomy.md#usesubscription)
- [useSubscriptions](react_autonomy.md#usesubscriptions)
- [useUser](react_autonomy.md#useuser)

### Other Functions

- [ChordProvider](react_autonomy.md#chordprovider)
- [useCheckout](react_autonomy.md#usecheckout)

## Type Aliases

### AddPromoCode

Ƭ **AddPromoCode**: `Object`

#### Type declaration

| Name | Type | Description |
| :------ | :------ | :------ |
| `promoCode` | `string` | The promo code to apply to the current shopping cart. |

#### Defined in

[packages/react-autonomy/src/redux/actions/cart/add-promo-code.ts:33](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/cart/add-promo-code.ts#L33)

___

### AddSubscriptionItem

Ƭ **AddSubscriptionItem**: `Object`

#### Type declaration

| Name | Type |
| :------ | :------ |
| `endDate` | `string` |
| `interval` | { `length`: `number` ; `unit`: [`IntervalUnit`](react_autonomy.md#intervalunit)  } |
| `interval.length` | `number` |
| `interval.unit` | [`IntervalUnit`](react_autonomy.md#intervalunit) |
| `quantity` | `number` |
| `sku` | `string` |

#### Defined in

[packages/react-autonomy/src/redux/actions/cart/add-subscription.ts:43](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/cart/add-subscription.ts#L43)

___

### AddToCartItem

Ƭ **AddToCartItem**: `Object`

#### Type declaration

| Name | Type |
| :------ | :------ |
| `product?` | [`Product`](../interfaces/react_autonomy.Product.md) |
| `quantity` | `number` |
| `sku` | `string` |

#### Defined in

[packages/react-autonomy/src/redux/actions/cart/add-to-cart.ts:36](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/cart/add-to-cart.ts#L36)

___

### Config

Ƭ **Config**: `ChordClientConfig`

#### Defined in

[packages/react-autonomy/src/types.ts:4](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/types.ts#L4)

___

### IntervalUnit

Ƭ **IntervalUnit**: ``"day"`` \| ``"week"`` \| ``"month"`` \| ``"year"``

#### Defined in

[packages/react-autonomy/src/types.ts:29](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/types.ts#L29)

___

### LoadUserReferralIdentifier

Ƭ **LoadUserReferralIdentifier**: `Object`

#### Type declaration

| Name | Type |
| :------ | :------ |
| `email` | `string` |

#### Defined in

[packages/react-autonomy/src/redux/actions/user/get-or-load-referral-identifier.ts:26](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/user/get-or-load-referral-identifier.ts#L26)

___

### Login

Ƭ **Login**: `Object`

#### Type declaration

| Name | Type | Description |
| :------ | :------ | :------ |
| `email` | `string` | The user's email address. |
| `redirectURI?` | `string` | The URL that the user will be redirected to when they click the link they've received in an email. Defaults to `window.location.href`. |
| `showUI?` | `boolean` | Controls whether Magic's default UI will display from when `login` is called until the user clicks the link they've received in an email. Defaults to `false`. |

#### Defined in

[packages/react-autonomy/src/redux/actions/auth/login.ts:46](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/auth/login.ts#L46)

___

### Metadata

Ƭ **Metadata**: `Record`<`string` \| `number`, `unknown`\>

#### Defined in

node_modules/@chordcommerce/chord-js-autonomy/dist/oms/types/objects.d.ts:362

___

### ModifyGiftCards

Ƭ **ModifyGiftCards**: [`GiftCardsInput`](../interfaces/react_autonomy.GiftCardsInput.md)

#### Defined in

[packages/react-autonomy/src/redux/actions/cart/modify-gift-cards.ts:35](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/cart/modify-gift-cards.ts#L35)

___

### ModifyUser

Ƭ **ModifyUser**: `Object`

#### Type declaration

| Name | Type |
| :------ | :------ |
| `attributes` | `UserInput` |

#### Defined in

[packages/react-autonomy/src/redux/actions/user/modify-user.ts:27](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/user/modify-user.ts#L27)

___

### SubscriptionAddress

Ƭ **SubscriptionAddress**: `Object`

#### Type declaration

| Name | Type |
| :------ | :------ |
| `address1` | `string` |
| `address2` | `string` |
| `city` | `string` |
| `country_iso` | `string` |
| `name` | `string` |
| `state_name` | `string` |
| `zipcode` | `string` |

#### Defined in

[packages/react-autonomy/src/redux/actions/subscriptions/update-subscription.ts:33](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/subscriptions/update-subscription.ts#L33)

___

### SubscriptionPaymentSource

Ƭ **SubscriptionPaymentSource**: `Object`

#### Type declaration

| Name | Type |
| :------ | :------ |
| `cc_type` | `string` |
| `gateway_payment_profile_id` | `string` |
| `last_digits` | `string` |
| `month` | `number` |
| `name` | `string` |
| `year` | `number` |

#### Defined in

[packages/react-autonomy/src/redux/actions/subscriptions/update-subscription.ts:43](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/subscriptions/update-subscription.ts#L43)

___

### TrackCartViewed

Ƭ **TrackCartViewed**: `Object`

#### Type declaration

| Name | Type | Description |
| :------ | :------ | :------ |
| `products?` | [`Product`](../interfaces/react_autonomy.Product.md)[] | The products in the customer's cart. |

#### Defined in

[packages/react-autonomy/src/redux/actions/analytics/track-cart-viewed.ts:4](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/analytics/track-cart-viewed.ts#L4)

___

### TrackCollectionClicked

Ƭ **TrackCollectionClicked**: `Object`

#### Type declaration

| Name | Type | Description |
| :------ | :------ | :------ |
| `collection` | [`Collection`](../interfaces/react_autonomy.Collection.md) | The collection the customer clicked. |

#### Defined in

[packages/react-autonomy/src/redux/actions/analytics/track-collection-clicked.ts:4](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/analytics/track-collection-clicked.ts#L4)

___

### TrackProductViewed

Ƭ **TrackProductViewed**: `Object`

#### Type declaration

| Name | Type | Description |
| :------ | :------ | :------ |
| `product` | [`Product`](../interfaces/react_autonomy.Product.md) | The product the customer viewed. |

#### Defined in

[packages/react-autonomy/src/redux/actions/analytics/track-product-viewed.ts:4](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/redux/actions/analytics/track-product-viewed.ts#L4)

## Hook Functions

### useAnalytics

▸ **useAnalytics**(): [`UseAnalytics`](../interfaces/react_autonomy.UseAnalytics.md)

The `useAnalytics` hook returns a set of functions that sends events to
Segment.

**`Example`**

```javascript
import { useAnalytics } from '@chordcommerce/react-autonomy'

const ProductLink = ({ children, product }) => {
  const { trackProductClicked } = useAnalytics()
  const url = `/products/${product.slug}/`

  return (
    <a href={url} onClick={() => trackProductClicked({ product })}>
      {children}
    </a>
  )
}
```

#### Returns

[`UseAnalytics`](../interfaces/react_autonomy.UseAnalytics.md)

#### Defined in

[packages/react-autonomy/src/hooks/use-analytics.ts:53](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-analytics.ts#L53)

___

### useAuth

▸ **useAuth**(): [`UseAuth`](../interfaces/react_autonomy.UseAuth.md)

The `useAuth` hook returns information about the current authentication
session, and functions for logging in and logging out. Chord's preferred
authentication provider is [Magic](https://magic.link/) through our
[chord-magic package](https://github.com/chordcommerce/chord-ui/pkgs/npm/chord-magic).

**`Example`**

```javascript
import { useAuth } from '@chordcommerce/react-autonomy'

const AccountPage = () => {
  const { isLoggedIn } = useAuth()
  if (!isLoggedIn) return

  // return account page
}
```

#### Returns

[`UseAuth`](../interfaces/react_autonomy.UseAuth.md)

#### Defined in

[packages/react-autonomy/src/hooks/use-auth.ts:36](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-auth.ts#L36)

___

### useCart

▸ **useCart**(): [`UseCart`](../interfaces/react_autonomy.UseCart.md)

The `useCart` hook returns information about the current shopping cart, and
functions for creating and updating the shopping cart.

**`Example`**

```javascript
import { useCart } from '@chordcommerce/react-autonomy'

// inside a function component
const { cart, addToCart } = useCart()
```

#### Returns

[`UseCart`](../interfaces/react_autonomy.UseCart.md)

#### Defined in

[packages/react-autonomy/src/hooks/use-cart.ts:56](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-cart.ts#L56)

___

### useProduct

▸ **useProduct**(): [`UseProduct`](../interfaces/react_autonomy.UseProduct.md)

The `useProduct` hook returns a set of functions for product-related operations.

**`Example`**

```javascript
import { useProduct } from '@chordcommerce/react-autonomy'

const NotifyWhenBackInStockButton = ({ email, sku }) => {
  const { createStockRequest } = useProduct()

  const onClick = () => createStockRequest({ email, sku })

  return <button onClick={onClick}>Notify</button>
}
```

#### Returns

[`UseProduct`](../interfaces/react_autonomy.UseProduct.md)

#### Defined in

[packages/react-autonomy/src/hooks/use-product.ts:30](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-product.ts#L30)

___

### useSubscription

▸ **useSubscription**(`props`): [`UseSubscription`](../interfaces/react_autonomy.UseSubscription.md)

The `useSubscription` hook returns the current loaded subscription and
functions for managing the subscription.

This function has a side effect that will automatically start loading the
subscription, if needed, upon initialization.

**`Example`**

```javascript
import { useSubscription } from '@chordcommerce/react-autonomy'

export default () => {
  const { subscription, isFetching } = useSubscription({ subscriptionId: 10000 })

  if (isFetching) {
    return (
      <p>Loading…</p>
    )
  }

  return (
    <p>Your subscription will be renewed on {subscription.actionableDate}</p>
  )
}
```

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `props` | `Object` |  |
| `props.subscriptionId` | `string` \| `number` | The ID of the subscription to load and manage. |

#### Returns

[`UseSubscription`](../interfaces/react_autonomy.UseSubscription.md)

#### Defined in

[packages/react-autonomy/src/hooks/use-subscription.ts:64](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-subscription.ts#L64)

___

### useSubscriptions

▸ **useSubscriptions**(): [`UseSubscriptions`](../interfaces/react_autonomy.UseSubscriptions.md)

The `useSubscriptions` hook returns an object representing the current user's
subscriptions.

This hook has a side effect that will load all the user's subscriptions upon
calling it, if not already loaded.

**`Example`**

```javascript
import { useSubscriptions } from '@chordcommerce/react-autonomy'

const SubscriptionsPage = () => {
  const { subscriptions, isLoaded, isFetching, error } = useSubscriptions()

  if (isFetching) {
    return <p>Loading…</p>
  }

  return (
    <dl>
      {subscriptions.map(subscription => (
        <React.Fragment key={subscription.id}>
          <dt>Subscription #{subscription.id}</dt>
          <dd>
            Renews every {subscription.intervalLength} {subscription.intervalUnit}
            <br />
            (Items: {subscription.lineItems.map(li => li.sku).join(', ')})
          </dd>
        </React.Fragment>
      )}
    </dl>
  )
}
```

#### Returns

[`UseSubscriptions`](../interfaces/react_autonomy.UseSubscriptions.md)

#### Defined in

[packages/react-autonomy/src/hooks/use-subscriptions.ts:46](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-subscriptions.ts#L46)

___

### useUser

▸ **useUser**(): [`UseUser`](../interfaces/react_autonomy.UseUser.md)

The `useUser` hook returns the current user and functions for loading data
about the user. At the moment, the only user information Chord supports is
the user's referral identifier and personalized referral url.

Using this hook will automatically load the user as a side effect, they are
not already loaded.

**`Example`**

```javascript
import { useUser } from '@chordcommerce/react-autonomy'

const AccountPage = () => {
  const { user, loadUser } = useUser()

  return <h1>Hello {user.name}</h1>
}
```

#### Returns

[`UseUser`](../interfaces/react_autonomy.UseUser.md)

#### Defined in

[packages/react-autonomy/src/hooks/use-user.ts:39](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-user.ts#L39)

___

## Other Functions

### ChordProvider

▸ **ChordProvider**(`props`, `context?`): `ReactElement`<`any`, `any`\>

React context provider for Chord services. This component is mainly a wrapper
for a [Redux](https://redux.js.org/) store that powers Chord's analytics,
cart, checkout, subscription and user models.

**`Example`**

```javascript
import ChordProvider from '@chordcommerce/react-autonomy'
import MagicClient from '@chordcommerce/chord-magic'

const App = ({ children }) => {
 const magicClient = new MagicClient(process.env.MAGIC_API_KEY)

  return (
    <ChordProvider
      config={{
        domain: process.env.CHORD_DOMAIN,
        brandName: process.env.CHORD_BRAND_NAME,
        storeId: process.env.CHORD_STORE_ID,
        omsId: process.env.CHORD_OMS_ID,
        tenantId: process.env.CHORD_TENANT_ID,
      }}
      authClient={magicClient}
    >
     {children}
    </ChordProvider>
  )
}
```

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `PropsWithChildren`<[`ChordProviderProps`](../interfaces/react_autonomy.ChordProviderProps.md)\> |
| `context?` | `any` |

#### Returns

`ReactElement`<`any`, `any`\>

#### Defined in

node_modules/@types/react/index.d.ts:520

___

### useCheckout

▸ **useCheckout**(): `Object`

#### Returns

`Object`

| Name | Type |
| :------ | :------ |
| `completeAddressStep` | (...`args`: [order: CheckoutOrderInput]) => `Promise`<[`OrderBig`](../interfaces/react_autonomy.OrderBig.md)\> |
| `completeDeliveryStep` | (...`args`: [order: CheckoutOrderInput]) => `Promise`<[`OrderBig`](../interfaces/react_autonomy.OrderBig.md)\> |
| `completePaymentStep` | (...`args`: [order: CheckoutOrderInput]) => `Promise`<[`OrderBig`](../interfaces/react_autonomy.OrderBig.md)\> |
| `finalizeCheckout` | (...`args`: [options?: FinalizeCheckoutInput]) => `Promise`<[`OrderBig`](../interfaces/react_autonomy.OrderBig.md)\> |
| `getStates` | (...`args`: [options: GetStates]) => `Promise`<`CountryStates`\> |
| `modifyCheckout` | (...`args`: [input: CheckoutOrderInput \| CheckoutInput]) => `Promise`<[`OrderBig`](../interfaces/react_autonomy.OrderBig.md)\> |
| `prepareCheckout` | (...`args`: [options?: Checkout]) => `Promise`<[`OrderBig`](../interfaces/react_autonomy.OrderBig.md)\> |

#### Defined in

[packages/react-autonomy/src/hooks/use-checkout.ts:14](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-autonomy/src/hooks/use-checkout.ts#L14)
