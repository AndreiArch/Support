[@chordcommerce/chord-ui](../README.md) / [Modules](../modules.md) / react-performance

# Module: react-performance

## Table of contents

### Variables

- [default](react_performance.md#default)

## Variables

### default

• **default**: `Object`

#### Defined in

[packages/react-performance/src/index.ts:1](https://github.com/chordcommerce/chord-ui/blob/8d28f94/packages/react-performance/src/index.ts#L1)
