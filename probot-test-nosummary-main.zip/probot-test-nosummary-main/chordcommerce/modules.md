[@chordcommerce/chord-ui](README.md) / Modules

# @chordcommerce/chord-ui

## Table of contents

### Modules

- [react-autonomy](modules/react_autonomy.md)
- [react-performance](modules/react_performance.md)
