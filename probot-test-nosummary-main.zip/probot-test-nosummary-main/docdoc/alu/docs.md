# ALU/docs.md Cale relativa 2222

::partial{file="../header.md"}

::::link-array
:::link-array-item{headerType="IMAGE" headerImage="https://archbee-image-uploads.s3.amazonaws.com/60yoq2sm2EvcxIGf-bRy7/7cBO3M0M64bvOQ5QDRujH_2511527594592372137496735684337349238663318n.jpg"}

- da da da
- da da nU

:::

:::link-array-item{headerType="COLOR" headerColor="#ff00FF"}

- [ ] check box
- [x] check box 222
- [ ] efasdfasdfasdfasdf2222
- [x] fasdfadsfasd

:::
::::


## Continue Mailgun Setup 222:

**1. Verify the email address and display name  with client** - ****&#x20;

* This is the name and domain they would like to use for email notifications
* Common choices for the email are "noreply@(partners domain) or "yourloanofficer@(partners domain)" or "(partners name)@(partners domain)"&#x20;
* Common choices for the display name are the partner name, or "Your Loan Officer"

**2. After the client has finished setup** and the domain is verified, go to "_Domain settings_" > "_SMTP Credentials_", copy the Login and place it in "_SMTP User Name_" field in the MortgageHippo management portal

**3. Click on** "_Reset password_", then click “_Copy_” on the black pop up message in the lower right hand corner

**4. Paste the password** in the "_SMTP Password_" field in the MortgageHippo management Portal

![SMTP Credentials Snapshot](https://lh3.googleusercontent.com/GBHo54fAfcaaYqARTn-VytOuMnccPGEk1fzc1JVU9Mjn5pTN98mI5dg4OfCRTxQPCLQ7mtY7DqIz3fDIyiwfyHHzUOctdFA1plmWUvtOoOZ5cNa228xoAAmAMq1kI51MXWDoAjyb=s0)

![Edit Email Provider Credentials Snapshot](https://lh3.googleusercontent.com/-nDddhjfkzV56FTb9H4Ntq3AJwMPcHZtqgjw5JJWC70q1vLzeDLpl2vlVGh0mw-EQjk21vE27z2C39cXt6MJ7\_UEAGw8fEf27MyvCq7ZuH-ioRLFq4vS-2tDhnK912qSmwstyXZ-=s0)

{% hint style="danger" %}
**Warning: If performing the steps below to add the email to auth0, test functionality. There have been issues with this setup that have caused auth0 login to no longer function.**
{% endhint %}

-1.

!["found"](../.gitbook/assets/poza-palarie-paie-assets.jpg "found")

-2.

!["found"](<.gitbook/assets/poza-palarie-paie copy.jpg> "found")

-3.

!["not found"](<assetsfolder/sss/poza-palarie-paie copy.jpg> "not found")

-4.

!["not found"](sssss/poza-palarie-paie.jpg "not found")

-5.

!["not found"](<.gitbook/assets/image (258).png> "not found")

-6.

<img src="../.gitbook/assets/Screen Shot 2022-09-12 at 12.32.15 PM.png" alt="" data-size="original">