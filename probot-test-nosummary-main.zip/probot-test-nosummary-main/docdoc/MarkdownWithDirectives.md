# Demo directives

Sometimes this ↓ text isn't redered properly because of directives

something:something
something: something

This is a bold **text**

http://www.archbee.io

## Tabs

:::::tabs
::::tab{title="Tab 1"}
Some content for Tab 1

:::hint{style="info"}
Pull requests are very welcome! Please see CONTRIBUTING.md for more information.
Tthis is really nice
:::

- [x] This is a checkbox list
- [x] This is a checkbox list
- [ ] This is done
- [ ] This is a checkbox list
      ::::

:::tab{title="Tab Photos"}
![](https://placehold.co/600x400)

We would love you to contributeaaa
:::
:::::

---

## Hints

:::hint
We would love you to contribute to `@octokit/rest`, pull requests are very welcome! Please see CONTRIBUTING.md for more information.
:::

:::hint{style="info"}
We would love you to contribute to `@octokit/rest`, pull requests are very welcome! Please see CONTRIBUTING.md for more information.
:::

:::hint{style="warning"}
We would love you to contribute to @octokit/rest, pull requests are very welcome! Please see CONTRIBUTING.md for more information.
:::

:::hint{style="success"}
We would love you to contribute to @octokit/rest, pull requests are very welcome! Please see CONTRIBUTING.md for more information.
:::

---

## Link Array

::::link-array
:::link-array-item{headerType="IMAGE" headerImage="https://placehold.co/600x400"}

- list item 1
- list item 2
  :::
  :::link-array-item{headerType="COLOR" headerColor="#ff00FF"}

- [ ] unchecked list box
- [x] checked list box
      :::
      ::::

## Code block

```nodejs
dadada
```

## Code blocks

:::::codeblocktabs

```
// code block not specified
```

```
// code block not specified
```

```
// code block not specified
```

:::::

## Demo Code Blocks

:::::codeblocktabs

```php
// PHP is the best.
```

```java
// and JAVA too
```

```go
// demo go
```

```javascript
// demo js
```

:::::

---

{% hint style="info" %}
some hint
{% endhint %}

---

{% tabs %}
{% tab title="tab 2" %}some tab fasdfasdfasdfasdfads {% endtab %}
{% tab title="tab 2" %}some tab fasdfasdfasdfasdfads {% endtab %}
{% tab title="tab 2" %}some tab fasdfasdfasdfasdfads {% endtab %}
{% tab title="tab 2" %}some tab fasdfasdfasdfasdfads
{% endtab %}
{% endtabs %}
