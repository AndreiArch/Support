# Markdown htmltag -> Accepted tags

## html images :rocket:

<img src="./asdasd/someimge.jpg" alt="Crypto exchange" />

### Multi line image

<figure>
    <img src="/assets/images/albuquerque.jpg"
         alt="Albuquerque, New Mexico">
    <figcaption>A single track trail outside of Albuquerque, New Mexico.</figcaption>
</figure>

## HTML Links

### links in lists

- <a href="asadasd" title="Chuck Norris " target="_blank" >wowoww</a>
- A JCV <a href="asadasd" title="JCV" target="_blank" >profil</a>

## link in paragraph

<a href="asadasd" title="Alup Igus " target="_blank" >wowoww</a>

<a href="https://flaviocopes.com/mysql-how-to-install"> starts with link </a> :

link in the middle <a href="https://flaviocopes.com/mysql-how-to-install"> middle klink</a> end text

link in the middle <a href="https://flaviocopes.com/mysql-how-to-install"> middle klink</a> asdas middle <a href="https://flaviocopes.com/mysql-how-to-install"> middle klink</a> end text

## table

### short table

| First Header | Second Header |
| ------------ | ------------- |
| Content Cell | Content Cell  |
| Content Cell | Content Cell  |

## Emoji in paragraph

:memo: **Note:** Sunrises are beautiful.

### emoji in blockquote and text color

- ~~The world is flat.~~ We now know that the world is round. <font color="red">This text is red!</font>

> :warning: **Warning:** Do not push the big red button.

> :memo: **Note:** Sunrises are beautiful.

> :bulb: **Tip:** Remember to appreciate the little things in life.

## special text

- Copyright (©) — &copy;
- Registered trademark (®) — &reg;
- Trademark (™) — &trade;
- Euro (€) — &euro;
- Left arrow (←) — &larr;
- Up arrow (↑) — &uarr;
- Right arrow (→) — &rarr;
- Down arrow (↓) — &darr;
- Degree (°) — &#176;
- Pi (π) — &#960;
