::partial{file="header.md"}

# Doc Doc !!!2222

::::link-array
:::link-array-item{headerType="IMAGE" headerImage="https://archbee-image-uploads.s3.amazonaws.com/60yoq2sm2EvcxIGf-bRy7/7cBO3M0M64bvOQ5QDRujH_2511527594592372137496735684337349238663318n.jpg"}

- da da da
- da da nUaaaa
- [Link](1.aaa2.md)
  :::

:::link-array-item{headerType="COLOR" headerColor="#ff00FF"}

- [ ] check box
- [x] check box
- [ ] asdasdas
:::
::::


## Continue Mailgun Setup:

**1. Verify the email address and display name  with client** - ****&#x20;

* This is the name and domain they would like to use for email notifications
* Common choices for the email are "noreply@(partners domain) or "yourloanofficer@(partners domain)" or "(partners name)@(partners domain)"&#x20;
* Common choices for the display name are the partner name, or "Your Loan Officer"

**2. After the client has finished setup** and the domain is verified, go to "_Domain settings_" > "_SMTP Credentials_", copy the Login and place it in "_SMTP User Name_" field in the MortgageHippo management portal

**3. Click on** "_Reset password_", then click “_Copy_” on the black pop up message in the lower right hand corner

**4. Paste the password** in the "_SMTP Password_" field in the MortgageHippo management Portal

![SMTP Credentials Snapshot](https://lh3.googleusercontent.com/GBHo54fAfcaaYqARTn-VytOuMnccPGEk1fzc1JVU9Mjn5pTN98mI5dg4OfCRTxQPCLQ7mtY7DqIz3fDIyiwfyHHzUOctdFA1plmWUvtOoOZ5cNa228xoAAmAMq1kI51MXWDoAjyb=s0)

![Edit Email Provider Credentials Snapshot](https://lh3.googleusercontent.com/-nDddhjfkzV56FTb9H4Ntq3AJwMPcHZtqgjw5JJWC70q1vLzeDLpl2vlVGh0mw-EQjk21vE27z2C39cXt6MJ7\_UEAGw8fEf27MyvCq7ZuH-ioRLFq4vS-2tDhnK912qSmwstyXZ-=s0)

{% hint style="danger" %}
**Warning: If performing the steps below to add the email to auth0, test functionality. There have been issues with this setup that have caused auth0 login to no longer function.**
{% endhint %}


![](assetsfolder/poza-palarie-paie.jpg)
![](<assetsfolder/sss/poza-palarie-paie copy.jpg>)

![](sssss/poza-palarie-paie.jpg)

![](<.gitbook/assets/image (258).png>)

<img src="../.gitbook/assets/Screen Shot 2022-09-12 at 12.32.15 PM.png" alt="" data-size="original">