# BBB ---123111

## 1json 111
::partial{file="/package.json#L9-L12"}

## 2 swagerr
::use{file="swagger-v2.json" from="51" to="58" syntax="javascript"}

## 3
::partial{file="swagger-v2.json#L2"}

## 5 with dot
::partial{file="/.archbee.yaml#L1-L5"}

## 5 with root
::partial{file="/aaa#L1-L5"}

## 5 undef range to
::partial{file="/aaa#L1-L5000"}

## 5 undef range from to
::partial{file="/aaa#L100-L5000"}

## 5 with reverse
::partial{file="../aaa#L1-L5"}

## 5 some hash tag
::partial{file="../aaa#afsdfasdfasdfas"}

## 6
::partial{file="../aaa#L5-L1"}

## 2 invalid number
::use{file="swagger-v2.json" from="adfasd" to="58" syntax="javascript"}

## slate
::partial{file="../slate/general/faq.md#L17-L23" syntax="JSON"}

# BBBBB


- [x] check box
- [x] check box
      
```nodejs

dadada

```




## fgddfsfdgd

rtyrty

:::hint
pppopopopopoopoooo
:::

***

:::hint
fasdfasdfasfasdfasd
:::

